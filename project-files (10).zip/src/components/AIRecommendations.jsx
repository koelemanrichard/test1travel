import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Link } from 'react-router-dom';
import * as FiIcons from 'react-icons/fi';
import SafeIcon from '../common/SafeIcon';
import { useFavorites } from '../contexts/FavoritesContext';
import supabase from '../lib/supabase';

const {
  FiStar, FiMapPin, FiHeart, FiTrendingUp, FiRefreshCw, FiCheck, FiSliders,
  FiCpu, FiZap, FiTarget, FiThumbsUp, FiThumbsDown, FiLoader, FiActivity, FiX
} = FiIcons;

const AIRecommendations = () => {
  const [recommendations, setRecommendations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [processingAI, setProcessingAI] = useState(false);
  const [userProfile, setUserProfile] = useState(() => {
    const saved = localStorage.getItem('ai-user-profile');
    return saved ? JSON.parse(saved) : {
      preferences: [],
      favoriteLocations: [],
      favoriteTypes: [],
      pricePreference: 'mid',
      adventureLevel: 'moderate',
      viewedProperties: [],
      feedbackHistory: []
    };
  });
  
  const [aiInsights, setAiInsights] = useState(null);
  const [preferenceOptions] = useState([
    'Adventure', 'Relaxation', 'Romance', 'Family', 'Culture', 
    'Nature', 'Luxury', 'Budget', 'Photography', 'Food', 
    'Wellness', 'History', 'Unique', 'Secluded', 'Social'
  ]);
  
  const [activeTab, setActiveTab] = useState('forYou');
  const [showExplanation, setShowExplanation] = useState(false);
  const [showPreferences, setShowPreferences] = useState(false);
  const [aiEvolution, setAiEvolution] = useState(0); // 0-100% how much AI has learned
  const [aiMessage, setAiMessage] = useState(null);
  const [insights, setInsights] = useState([]);
  
  const { favorites, isFavorite, addFavorite, removeFavorite } = useFavorites();
  const recommendationsRef = useRef();
  const initialLoadComplete = useRef(false);

  // Maximum number of recommendations to show
  const MAX_RECOMMENDATIONS = 10;

  // Save user profile to localStorage when it changes
  useEffect(() => {
    localStorage.setItem('ai-user-profile', JSON.stringify(userProfile));
  }, [userProfile]);

  // Initialize AI recommendations based on favorites and user profile
  useEffect(() => {
    const generateRecommendations = async () => {
      if (initialLoadComplete.current) return;
      
      setLoading(true);
      setProcessingAI(true);
      setAiMessage("Analyzing your preferences and building personalized recommendations...");
      
      try {
        // First, analyze user's existing favorites to extract preferences
        await analyzeUserFavorites();
        
        // Simulate AI processing time for better UX
        await new Promise(resolve => setTimeout(resolve, 1500));
        setAiMessage("Searching for extraordinary stays that match your taste...");
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        // Fetch AI recommended properties from Supabase
        const { data, error } = await supabase
          .from('properties_j293sk4l59')
          .select('*')
          .eq('status', 'Active')
          .order('rating', { ascending: false })
          .limit(MAX_RECOMMENDATIONS); // Limit to 10 recommendations
          
        if (error) {
          console.error('Error fetching AI recommendations:', error);
          setRecommendations(mockStays.slice(0, MAX_RECOMMENDATIONS));
        } else {
          console.log('AI recommendations fetched:', data);
          if (data && data.length > 0) {
            // Process the data with our AI algorithm
            const processedRecommendations = processRecommendationsWithAI(data);
            // Ensure we don't exceed the maximum
            setRecommendations(processedRecommendations.slice(0, MAX_RECOMMENDATIONS));
            
            // Generate AI insights based on the recommendations
            generateAIInsights(processedRecommendations.slice(0, MAX_RECOMMENDATIONS));
          } else {
            setRecommendations(mockStays.slice(0, MAX_RECOMMENDATIONS));
          }
        }
        
        setAiMessage("Finalizing your personalized travel inspiration...");
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Calculate AI evolution percentage based on user interactions
        const evolutionPercent = calculateAIEvolution();
        setAiEvolution(evolutionPercent);
        
        initialLoadComplete.current = true;
      } catch (error) {
        console.error('Failed to fetch AI recommendations:', error);
        setRecommendations(mockStays.slice(0, MAX_RECOMMENDATIONS));
      } finally {
        setLoading(false);
        setProcessingAI(false);
        setAiMessage(null);
      }
    };

    generateRecommendations();
  }, [favorites]);

  // Analyze user favorites to extract preferences
  const analyzeUserFavorites = async () => {
    if (favorites.length === 0) return;
    
    // Extract location patterns
    const locations = favorites.map(stay => stay.location?.split(',').pop().trim());
    const uniqueLocations = [...new Set(locations)].filter(Boolean);
    
    // Extract property type patterns
    const types = favorites.map(stay => stay.category);
    const uniqueTypes = [...new Set(types)].filter(Boolean);
    
    // Extract price patterns
    const prices = favorites.map(stay => parseFloat(stay.price?.replace(/[^\d.]/g, '') || 0));
    const avgPrice = prices.reduce((sum, price) => sum + price, 0) / prices.length;
    let pricePreference = 'mid';
    if (avgPrice < 150) pricePreference = 'budget';
    if (avgPrice > 350) pricePreference = 'luxury';
    
    // Update user profile with this information
    setUserProfile(prev => ({
      ...prev,
      favoriteLocations: uniqueLocations,
      favoriteTypes: uniqueTypes,
      pricePreference,
      viewedProperties: [...prev.viewedProperties, ...favorites.map(f => f.id)]
    }));
  };

  // Process recommendations using "AI" algorithm
  const processRecommendationsWithAI = (properties) => {
    // Start with all properties
    let processedData = properties.map(property => {
      // Calculate match score based on user profile
      let matchScore = 70; // Base score
      
      // Adjust score based on property type
      if (userProfile.favoriteTypes.includes(property.category)) {
        matchScore += 10;
      }
      
      // Adjust score based on location
      const propertyCountry = property.location?.split(',').pop().trim();
      if (userProfile.favoriteLocations.includes(propertyCountry)) {
        matchScore += 8;
      }
      
      // Adjust score based on price preference
      const price = parseFloat(property.price || 0);
      if (userProfile.pricePreference === 'budget' && price < 150) {
        matchScore += 7;
      } else if (userProfile.pricePreference === 'luxury' && price > 350) {
        matchScore += 7;
      } else if (userProfile.pricePreference === 'mid' && price >= 150 && price <= 350) {
        matchScore += 7;
      }
      
      // Adjust score based on user preferences
      if (property.features) {
        const features = Array.isArray(property.features) ? property.features : [property.features];
        
        if (userProfile.preferences.includes('Nature') && 
            (features.includes('Wildlife Viewing') || features.includes('Mountain Views'))) {
          matchScore += 5;
        }
        
        if (userProfile.preferences.includes('Luxury') && 
            (features.includes('Spa') || features.includes('Pool'))) {
          matchScore += 5;
        }
        
        if (userProfile.preferences.includes('Romance') && 
            (features.includes('Hot Tub') || features.includes('Fireplace'))) {
          matchScore += 5;
        }
      }
      
      // Cap score at 98 (we never say 100% match to maintain mystery)
      matchScore = Math.min(98, matchScore);
      
      // Generate personalized match reasons
      const matchReasons = generateMatchReasons(property, matchScore);
      
      return {
        id: property.id,
        name: property.name,
        location: property.location,
        image: property.image || 'https://images.unsplash.com/photo-1510798831971-661eb04b3739?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
        rating: property.rating || 4.8,
        price: property.price?.toString() || '0',
        category: property.category || 'Modern',
        matchScore: matchScore,
        matchReasons: matchReasons,
        features: property.features || [],
        uniqueAttributes: property.uniqueAttributes || generateUniqueAttributes(property)
      };
    });
    
    // Sort by match score and limit to maximum
    processedData.sort((a, b) => b.matchScore - a.matchScore);
    
    return processedData.slice(0, MAX_RECOMMENDATIONS);
  };
  
  // Generate match reasons based on property and user profile
  const generateMatchReasons = (property, score) => {
    const reasons = [];
    
    // Add preference-based reason if we have preferences
    if (userProfile.preferences.length > 0) {
      const preference = userProfile.preferences[Math.floor(Math.random() * userProfile.preferences.length)];
      reasons.push(`Based on your ${preference} preference`);
    } else {
      reasons.push('Matches your browsing patterns');
    }
    
    // Add property type reason
    if (userProfile.favoriteTypes.includes(property.category)) {
      reasons.push(`Similar to your favorite ${property.category.toLowerCase()} stays`);
    }
    
    // Add location-based reason
    const propertyCountry = property.location?.split(',').pop().trim();
    if (userProfile.favoriteLocations.includes(propertyCountry)) {
      reasons.push(`In your preferred destination: ${propertyCountry}`);
    }
    
    // Add a high-match reason if score is high
    if (score > 90) {
      reasons.push('Exceptional match for your travel style');
    }
    
    return reasons;
  };
  
  // Generate unique attributes for properties that don't have them
  const generateUniqueAttributes = (property) => {
    const attributes = [];
    
    if (property.category === 'Treehouse') {
      attributes.push('Elevated living experience');
      attributes.push('Immersed in nature');
    } else if (property.category === 'Castle') {
      attributes.push('Historic architecture');
      attributes.push('Royal experience');
    } else if (property.category === 'Modern') {
      attributes.push('Contemporary design');
      attributes.push('Cutting-edge amenities');
    } else {
      attributes.push('One-of-a-kind stay');
      attributes.push('Memorable experience');
    }
    
    return attributes;
  };
  
  // Generate AI insights based on the recommendations
  const generateAIInsights = (recommendations) => {
    const insights = [];
    
    // Insight 1: Most common property type
    const typeCount = {};
    recommendations.forEach(rec => {
      typeCount[rec.category] = (typeCount[rec.category] || 0) + 1;
    });
    const mostCommonType = Object.entries(typeCount)
      .sort((a, b) => b[1] - a[1])[0][0];
    
    insights.push({
      title: "Your Preferred Stay Type",
      description: `You seem to enjoy ${mostCommonType.toLowerCase()} accommodations. We've highlighted more of these for you.`,
      icon: FiTarget
    });
    
    // Insight 2: Price preference
    insights.push({
      title: "Budget Insight",
      description: `Based on your browsing, you prefer ${userProfile.pricePreference === 'budget' ? 'affordable' : userProfile.pricePreference === 'luxury' ? 'premium' : 'mid-range'} accommodations.`,
      icon: FiActivity
    });
    
    // Insight 3: Location preference
    if (userProfile.favoriteLocations.length > 0) {
      insights.push({
        title: "Destination Preference",
        description: `You seem interested in ${userProfile.favoriteLocations.join(', ')}. We've found more stays in these regions.`,
        icon: FiMapPin
      });
    }
    
    setInsights(insights);
    
    // Create AI insight message
    setAiInsights({
      mainInsight: `Based on your preferences and browsing history, you seem to enjoy ${mostCommonType.toLowerCase()} stays in ${userProfile.favoriteLocations[0] || 'unique locations'}.`,
      suggestion: `Try exploring our ${userProfile.favoriteTypes.length > 0 ? userProfile.favoriteTypes[0] : 'Treehouse'} options for your next adventure.`
    });
  };
  
  // Calculate how much the AI has "learned" about the user
  const calculateAIEvolution = () => {
    let evolutionScore = 0;
    
    // More preferences = better understanding
    evolutionScore += userProfile.preferences.length * 5;
    
    // More favorite locations = better understanding
    evolutionScore += userProfile.favoriteLocations.length * 10;
    
    // More favorite types = better understanding
    evolutionScore += userProfile.favoriteTypes.length * 10;
    
    // More viewed properties = better understanding
    evolutionScore += Math.min(userProfile.viewedProperties.length * 2, 30);
    
    // More feedback = better understanding
    evolutionScore += userProfile.feedbackHistory.length * 5;
    
    // Cap at 100%
    return Math.min(evolutionScore, 100);
  };

  // Toggle preference selection
  const togglePreference = (preference) => {
    setUserProfile(prev => {
      const updatedPreferences = prev.preferences.includes(preference)
        ? prev.preferences.filter(p => p !== preference)
        : [...prev.preferences, preference];
      
      return { ...prev, preferences: updatedPreferences };
    });
  };

  // Handle favorite toggle
  const handleFavoriteToggle = (e, stay) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (isFavorite(stay.id)) {
      removeFavorite(stay.id);
    } else {
      addFavorite(stay);
    }
  };

  // Record user feedback on recommendations
  const recordFeedback = (stayId, isPositive) => {
    setUserProfile(prev => ({
      ...prev,
      feedbackHistory: [
        ...prev.feedbackHistory,
        { stayId, isPositive, timestamp: new Date().toISOString() }
      ]
    }));
    
    // Show feedback message
    setAiMessage(isPositive 
      ? "Thanks! I'll show you more stays like this." 
      : "Noted! I'll adjust your recommendations.");
    
    setTimeout(() => setAiMessage(null), 2000);
    
    // Recalculate AI evolution
    const evolutionPercent = calculateAIEvolution();
    setAiEvolution(evolutionPercent);
  };

  // Refresh recommendations with "improved" AI
  const handleRefresh = async () => {
    setLoading(true);
    setProcessingAI(true);
    setAiMessage("Refreshing recommendations with your latest preferences...");
    
    // Simulate AI processing
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    try {
      // Fetch data and reprocess with updated user profile
      const { data, error } = await supabase
        .from('properties_j293sk4l59')
        .select('*')
        .eq('status', 'Active')
        .order('created_at', { ascending: false })
        .limit(MAX_RECOMMENDATIONS); // Limit refresh results too
      
      if (error) {
        throw error;
      }
      
      // Process with "improved" AI
      const refreshedRecommendations = processRecommendationsWithAI(data);
      setRecommendations(refreshedRecommendations.slice(0, MAX_RECOMMENDATIONS));
      
      // Generate new insights
      generateAIInsights(refreshedRecommendations.slice(0, MAX_RECOMMENDATIONS));
      
      // Update AI evolution
      const evolutionPercent = calculateAIEvolution();
      setAiEvolution(evolutionPercent);
      
      setAiMessage("Recommendations refreshed with your latest preferences!");
      setTimeout(() => setAiMessage(null), 2000);
    } catch (error) {
      console.error('Error refreshing recommendations:', error);
      setAiMessage("Couldn't refresh recommendations. Please try again.");
      setTimeout(() => setAiMessage(null), 2000);
    } finally {
      setLoading(false);
      setProcessingAI(false);
    }
  };

  // Mock data as fallback (limited to 10 items)
  const mockStays = [
    {
      id: 20,
      name: "Alpine Eco-Pod",
      location: "Swiss Alps, Switzerland",
      image: "https://images.unsplash.com/photo-1510798831971-661eb04b3739?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      rating: 4.9,
      price: "380",
      category: "Modern",
      matchScore: 98,
      matchReasons: ['Based on your Nature preference', 'Similar to Mountain Cave Retreat'],
      uniqueAttributes: ['Carbon-neutral design', 'Floor-to-ceiling windows']
    },
    {
      id: 21,
      name: "Lakeside Glass Cabin",
      location: "Ontario, Canada",
      image: "https://images.unsplash.com/photo-1464146072230-91cabc968266?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      rating: 4.7,
      price: "290",
      category: "Forest Cabin",
      matchScore: 95,
      matchReasons: ['Based on your Photography preference', 'Similar to Desert Glass House'],
      uniqueAttributes: ['360° lake views', 'Stargazing skylight']
    },
    {
      id: 22,
      name: "Moroccan Desert Camp",
      location: "Sahara Desert, Morocco",
      image: "https://images.unsplash.com/photo-1561053362-2d9dd9f1f6e4?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      rating: 4.8,
      price: "190",
      category: "Desert Camp",
      matchScore: 92,
      matchReasons: ['Based on your Adventure preference', 'Unique desert experience'],
      uniqueAttributes: ['Traditional Berber tents', 'Camel trekking included']
    },
    {
      id: 23,
      name: "Icelandic Northern Lights Lodge",
      location: "Reykjavik, Iceland",
      image: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      rating: 4.9,
      price: "420",
      category: "Lodge",
      matchScore: 90,
      matchReasons: ['Based on your Nature preference', 'Northern Lights viewing'],
      uniqueAttributes: ['Aurora viewing deck', 'Geothermal hot tub']
    },
    {
      id: 24,
      name: "Japanese Ryokan Retreat",
      location: "Kyoto, Japan",
      image: "https://images.unsplash.com/photo-1545569341-9eb8b30979d9?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      rating: 4.6,
      price: "350",
      category: "Wellness Retreat",
      matchScore: 88,
      matchReasons: ['Based on your Culture preference', 'Traditional Japanese experience'],
      uniqueAttributes: ['Traditional tatami rooms', 'Authentic kaiseki meals']
    },
    {
      id: 25,
      name: "Norwegian Fjord Cabin",
      location: "Geiranger, Norway",
      image: "https://images.unsplash.com/photo-1464146072230-91cabc968266?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      rating: 4.8,
      price: "320",
      category: "Forest Cabin",
      matchScore: 85,
      matchReasons: ['Based on your Nature preference', 'Spectacular fjord views'],
      uniqueAttributes: ['Waterfall views', 'Hiking trail access']
    },
    {
      id: 26,
      name: "Bali Jungle Villa",
      location: "Ubud, Indonesia",
      image: "https://images.unsplash.com/photo-1470165311815-34e78ff7a111?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      rating: 4.7,
      price: "250",
      category: "Villa",
      matchScore: 83,
      matchReasons: ['Based on your Wellness preference', 'Jungle sanctuary'],
      uniqueAttributes: ['Infinity pool', 'Yoga pavilion']
    },
    {
      id: 27,
      name: "Scottish Highland Castle",
      location: "Highlands, Scotland",
      image: "https://images.unsplash.com/photo-1520637736862-4d197d17c92a?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      rating: 4.5,
      price: "480",
      category: "Castle",
      matchScore: 80,
      matchReasons: ['Based on your History preference', 'Medieval architecture'],
      uniqueAttributes: ['Historic great hall', 'Highland views']
    },
    {
      id: 28,
      name: "Amazon Eco Lodge",
      location: "Manaus, Brazil",
      image: "https://images.unsplash.com/photo-1596306499317-8490e6e45deb?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      rating: 4.6,
      price: "240",
      category: "Eco Lodge",
      matchScore: 78,
      matchReasons: ['Based on your Adventure preference', 'Rainforest immersion'],
      uniqueAttributes: ['Canopy walkway', 'Wildlife tours']
    },
    {
      id: 29,
      name: "Santorini Cave House",
      location: "Oia, Greece",
      image: "https://images.unsplash.com/photo-1613395877344-13d4a8e0d49e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      rating: 4.8,
      price: "420",
      category: "Cave",
      matchScore: 75,
      matchReasons: ['Based on your Romance preference', 'Sunset views'],
      uniqueAttributes: ['Cycladic architecture', 'Aegean Sea views']
    }
  ].slice(0, MAX_RECOMMENDATIONS); // Ensure we don't exceed the limit

  return (
    <section ref={recommendationsRef} className="py-12 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          whileInView={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-6"
        >
          <div className="flex items-center justify-center mb-2">
            <SafeIcon icon={FiCpu} className="h-6 w-6 text-primary-600 mr-2" />
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-gray-900">
              AI-Powered Recommendations
            </h2>
          </div>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Our AI analyzes your preferences and behavior to discover stays you'll love
          </p>
          <p className="text-sm text-gray-500 mt-2">
            Showing top {Math.min(recommendations.length, MAX_RECOMMENDATIONS)} personalized recommendations
          </p>
        </motion.div>

        {/* AI Insights Card */}
        {aiInsights && (
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="bg-gradient-to-r from-primary-600 to-primary-500 rounded-xl text-white p-6 mb-8 relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 w-32 h-32 -mt-8 -mr-8 bg-white opacity-10 rounded-full"></div>
            <div className="absolute bottom-0 left-0 w-24 h-24 -mb-6 -ml-6 bg-white opacity-10 rounded-full"></div>
            
            <div className="flex items-start">
              <div className="p-3 bg-white bg-opacity-20 rounded-lg mr-4">
                <SafeIcon icon={FiZap} className="h-6 w-6 text-white" />
              </div>
              <div>
                <h3 className="text-xl font-bold mb-2">AI Travel Insight</h3>
                <p className="text-white text-opacity-90 mb-3">{aiInsights.mainInsight}</p>
                <p className="text-white text-opacity-80 text-sm">{aiInsights.suggestion}</p>
              </div>
            </div>
            
            <div className="mt-4 pt-4 border-t border-white border-opacity-20 flex justify-between items-center">
              <div>
                <span className="text-sm text-white text-opacity-80">AI Understanding</span>
                <div className="w-32 bg-white bg-opacity-20 rounded-full h-2 mt-1">
                  <div 
                    className="bg-white rounded-full h-2 transition-all duration-1000"
                    style={{ width: `${aiEvolution}%` }}
                  ></div>
                </div>
              </div>
              <button
                onClick={() => setShowExplanation(true)}
                className="text-sm bg-white bg-opacity-20 hover:bg-opacity-30 px-3 py-1 rounded-full transition-all"
              >
                How This Works
              </button>
            </div>
          </motion.div>
        )}

        {/* Tab Navigation */}
        <div className="flex flex-wrap justify-center mb-8">
          <button
            onClick={() => setActiveTab('forYou')}
            className={`flex items-center px-4 py-2 mx-2 mb-2 rounded-full transition-colors ${
              activeTab === 'forYou'
                ? 'bg-primary-600 text-white'
                : 'bg-white text-gray-700 hover:bg-gray-100'
            }`}
          >
            <SafeIcon icon={FiTarget} className="h-4 w-4 mr-2" />
            For You
          </button>
          <button
            onClick={() => setActiveTab('insights')}
            className={`flex items-center px-4 py-2 mx-2 mb-2 rounded-full transition-colors ${
              activeTab === 'insights'
                ? 'bg-primary-600 text-white'
                : 'bg-white text-gray-700 hover:bg-gray-100'
            }`}
          >
            <SafeIcon icon={FiActivity} className="h-4 w-4 mr-2" />
            Travel Insights
          </button>
          <button
            onClick={() => setShowPreferences(true)}
            className="flex items-center px-4 py-2 mx-2 mb-2 rounded-full bg-white text-gray-700 hover:bg-gray-100 transition-colors"
          >
            <SafeIcon icon={FiSliders} className="h-4 w-4 mr-2" />
            Preferences
            {userProfile.preferences.length > 0 && (
              <span className="ml-2 bg-primary-600 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                {userProfile.preferences.length}
              </span>
            )}
          </button>
          <button
            onClick={handleRefresh}
            disabled={loading}
            className="flex items-center px-4 py-2 mx-2 mb-2 rounded-full bg-white text-gray-700 hover:bg-gray-100 transition-colors"
          >
            <SafeIcon 
              icon={FiRefreshCw} 
              className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} 
            />
            Refresh
          </button>
        </div>

        {/* AI Processing Overlay */}
        {processingAI && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="bg-white rounded-xl shadow-lg p-8 mb-8 text-center"
          >
            <div className="inline-block p-3 bg-primary-100 rounded-full mb-4">
              <SafeIcon icon={FiLoader} className="h-8 w-8 text-primary-600 animate-spin" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">AI Working</h3>
            <p className="text-gray-600 mb-4">{aiMessage || "Processing your preferences..."}</p>
            <div className="w-full bg-gray-200 rounded-full h-2.5 mb-4">
              <div className="bg-primary-600 h-2.5 rounded-full animate-pulse" style={{ width: '70%' }}></div>
            </div>
          </motion.div>
        )}

        {/* AI Message Toast */}
        <AnimatePresence>
          {aiMessage && !processingAI && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="fixed top-20 left-1/2 transform -translate-x-1/2 bg-gray-800 text-white px-4 py-2 rounded-lg shadow-lg z-50 flex items-center"
            >
              <SafeIcon icon={FiCpu} className="h-4 w-4 mr-2" />
              {aiMessage}
            </motion.div>
          )}
        </AnimatePresence>

        {/* For You Tab Content */}
        {activeTab === 'forYou' && (
          <>
            {/* Recommendations */}
            {loading && !processingAI ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                {[1, 2, 3, 4].map(i => (
                  <div key={i} className="bg-white rounded-2xl shadow-lg overflow-hidden animate-pulse">
                    <div className="h-64 bg-gray-300"></div>
                    <div className="p-6">
                      <div className="h-6 bg-gray-300 rounded mb-4 w-3/4"></div>
                      <div className="h-4 bg-gray-300 rounded mb-4 w-1/2"></div>
                      <div className="h-4 bg-gray-300 rounded mb-6 w-full"></div>
                      <div className="h-6 bg-gray-300 rounded w-1/4"></div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                {recommendations.map((stay, index) => (
                  <motion.div
                    key={stay.id}
                    initial={{ y: 50, opacity: 0 }}
                    whileInView={{ y: 0, opacity: 1 }}
                    transition={{ duration: 0.6, delay: index * 0.1 }}
                    viewport={{ once: true }}
                    whileHover={{ y: -10 }}
                    className="bg-white rounded-2xl shadow-lg overflow-hidden group cursor-pointer relative"
                  >
                    <Link to={`/stay/${stay.id}`}>
                      <div className="relative overflow-hidden">
                        <img
                          src={stay.image}
                          alt={stay.name}
                          className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-500"
                        />
                        <div className="absolute top-4 left-4 bg-primary-600 text-white px-3 py-1 rounded-full text-sm font-medium">
                          {stay.category}
                        </div>
                        <div className="absolute top-4 right-16 bg-green-600 text-white px-3 py-1 rounded-full text-sm font-medium flex items-center">
                          <SafeIcon icon={FiTrendingUp} className="h-3 w-3 mr-1" />
                          {stay.matchScore}% Match
                        </div>
                      </div>
                      <div className="p-6">
                        <div className="flex items-center justify-between mb-2">
                          <h3 className="text-xl font-semibold text-gray-900 group-hover:text-primary-600 transition-colors">
                            {stay.name}
                          </h3>
                          <div className="flex items-center space-x-1">
                            <SafeIcon icon={FiStar} className="h-4 w-4 text-yellow-400 fill-current" />
                            <span className="text-sm font-medium text-gray-700">{stay.rating}</span>
                          </div>
                        </div>
                        <div className="flex items-center space-x-1 mb-4">
                          <SafeIcon icon={FiMapPin} className="h-4 w-4 text-gray-400" />
                          <span className="text-gray-600">{stay.location}</span>
                        </div>
                        
                        {/* AI Match Reasons */}
                        <div className="mb-4">
                          {stay.matchReasons.map((reason, idx) => (
                            <p key={idx} className="text-xs text-green-600 mb-1 flex items-center">
                              <span className="inline-block w-1 h-1 bg-green-600 rounded-full mr-2"></span>
                              {reason}
                            </p>
                          ))}
                        </div>
                        
                        {/* Unique Attributes */}
                        {stay.uniqueAttributes && (
                          <div className="mb-3 flex flex-wrap gap-1">
                            {stay.uniqueAttributes.map((attr, idx) => (
                              <span key={idx} className="text-xs bg-primary-50 text-primary-700 px-2 py-0.5 rounded">
                                {attr}
                              </span>
                            ))}
                          </div>
                        )}
                        
                        <div className="flex items-center justify-between">
                          <span className="text-2xl font-bold text-primary-600">€{stay.price}</span>
                          <span className="text-gray-500">per night</span>
                        </div>
                      </div>
                    </Link>
                    
                    {/* Favorite button */}
                    <button
                      onClick={(e) => handleFavoriteToggle(e, stay)}
                      className="absolute top-4 right-4 bg-white bg-opacity-90 p-2 rounded-full shadow-md"
                    >
                      <SafeIcon
                        icon={FiHeart}
                        className={`h-5 w-5 ${
                          isFavorite(stay.id) ? 'text-red-500 fill-current' : 'text-gray-600'
                        }`}
                      />
                    </button>
                    
                    {/* Feedback buttons */}
                    <div className="absolute bottom-4 right-4 flex space-x-2">
                      <button
                        onClick={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          recordFeedback(stay.id, true);
                        }}
                        className="bg-white bg-opacity-90 p-1.5 rounded-full shadow-md hover:bg-green-50"
                        title="Show me more like this"
                      >
                        <SafeIcon icon={FiThumbsUp} className="h-4 w-4 text-green-600" />
                      </button>
                      <button
                        onClick={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          recordFeedback(stay.id, false);
                        }}
                        className="bg-white bg-opacity-90 p-1.5 rounded-full shadow-md hover:bg-red-50"
                        title="Show me less like this"
                      >
                        <SafeIcon icon={FiThumbsDown} className="h-4 w-4 text-red-600" />
                      </button>
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
          </>
        )}

        {/* Insights Tab Content */}
        {activeTab === 'insights' && (
          <div className="bg-white rounded-xl shadow-lg p-8">
            <h3 className="text-2xl font-semibold text-gray-900 mb-6">Your Travel Profile Insights</h3>
            
            {insights.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {insights.map((insight, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    className="bg-gray-50 rounded-lg p-6"
                  >
                    <div className="bg-primary-100 p-3 rounded-full w-12 h-12 flex items-center justify-center mb-4">
                      <SafeIcon icon={insight.icon} className="h-6 w-6 text-primary-600" />
                    </div>
                    <h4 className="text-lg font-medium text-gray-900 mb-2">{insight.title}</h4>
                    <p className="text-gray-600">{insight.description}</p>
                  </motion.div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <div className="bg-gray-100 p-4 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                  <SafeIcon icon={FiActivity} className="h-8 w-8 text-gray-400" />
                </div>
                <h4 className="text-lg font-medium text-gray-900 mb-2">No insights yet</h4>
                <p className="text-gray-600 max-w-md mx-auto">
                  As you interact with recommendations and save favorites, our AI will generate personalized insights about your travel preferences.
                </p>
              </div>
            )}
            
            {/* AI Evolution Card */}
            <div className="mt-8 bg-gray-50 p-6 rounded-lg">
              <h4 className="text-lg font-medium text-gray-900 mb-4">AI Understanding Progress</h4>
              <div className="flex items-center mb-4">
                <div className="flex-1 mr-4">
                  <div className="w-full bg-gray-200 rounded-full h-3">
                    <div
                      className="bg-primary-600 rounded-full h-3 transition-all duration-1000"
                      style={{ width: `${aiEvolution}%` }}
                    ></div>
                  </div>
                </div>
                <span className="text-lg font-semibold text-gray-900">{aiEvolution}%</span>
              </div>
              <p className="text-gray-600 text-sm">
                The more you interact with recommendations, save favorites, and provide feedback, the better our AI understands your preferences.
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Preferences Modal */}
      {showPreferences && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.3 }}
            className="bg-white rounded-xl p-6 max-w-lg w-full mx-4"
          >
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-2xl font-semibold text-gray-900">Your Travel Preferences</h3>
              <button
                onClick={() => setShowPreferences(false)}
                className="p-2 rounded-full hover:bg-gray-100 transition-colors"
              >
                <SafeIcon icon={FiX} className="h-6 w-6 text-gray-500" />
              </button>
            </div>

            <p className="text-gray-600 mb-6">
              Select preferences to help our AI recommend stays you'll love. The more you select, the more personalized your recommendations will be.
            </p>

            <div className="mb-6">
              <h4 className="font-medium text-gray-900 mb-3">Travel Interests</h4>
              <div className="flex flex-wrap gap-2">
                {preferenceOptions.map((preference) => (
                  <button
                    key={preference}
                    onClick={() => togglePreference(preference)}
                    className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                      userProfile.preferences.includes(preference)
                        ? 'bg-primary-600 text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    {userProfile.preferences.includes(preference) && (
                      <SafeIcon icon={FiCheck} className="h-3 w-3 inline-block mr-1" />
                    )}
                    {preference}
                  </button>
                ))}
              </div>
            </div>

            <div className="mb-6">
              <h4 className="font-medium text-gray-900 mb-3">Budget Preference</h4>
              <div className="flex space-x-4">
                {['budget', 'mid', 'luxury'].map((price) => (
                  <button
                    key={price}
                    onClick={() => setUserProfile(prev => ({ ...prev, pricePreference: price }))}
                    className={`px-4 py-2 rounded-lg text-sm font-medium flex-1 transition-colors ${
                      userProfile.pricePreference === price
                        ? 'bg-primary-600 text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    {price === 'budget' ? 'Budget' : price === 'mid' ? 'Mid-range' : 'Luxury'}
                  </button>
                ))}
              </div>
            </div>

            <div className="mb-6">
              <h4 className="font-medium text-gray-900 mb-3">Adventure Level</h4>
              <div className="flex space-x-4">
                {['relaxed', 'moderate', 'adventurous'].map((level) => (
                  <button
                    key={level}
                    onClick={() => setUserProfile(prev => ({ ...prev, adventureLevel: level }))}
                    className={`px-4 py-2 rounded-lg text-sm font-medium flex-1 transition-colors ${
                      userProfile.adventureLevel === level
                        ? 'bg-primary-600 text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    {level.charAt(0).toUpperCase() + level.slice(1)}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex justify-end">
              <button
                onClick={() => {
                  setShowPreferences(false);
                  handleRefresh();
                }}
                className="bg-primary-600 hover:bg-primary-700 text-white px-6 py-3 rounded-lg transition-colors"
              >
                Save & Update Recommendations
              </button>
            </div>
          </motion.div>
        </div>
      )}

      {/* How It Works Modal */}
      {showExplanation && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.3 }}
            className="bg-white rounded-xl p-6 max-w-lg w-full mx-4"
          >
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-2xl font-semibold text-gray-900">How AI Recommendations Work</h3>
              <button
                onClick={() => setShowExplanation(false)}
                className="p-2 rounded-full hover:bg-gray-100 transition-colors"
              >
                <SafeIcon icon={FiX} className="h-6 w-6 text-gray-500" />
              </button>
            </div>

            <div className="space-y-4">
              <div className="flex items-start">
                <div className="bg-primary-100 p-2 rounded-full mt-1 mr-3">
                  <SafeIcon icon={FiTarget} className="h-5 w-5 text-primary-600" />
                </div>
                <div>
                  <h4 className="font-medium text-gray-900">Preference Analysis</h4>
                  <p className="text-gray-600">Our AI analyzes your selected preferences, favorited stays, and browsing patterns to understand what you like.</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="bg-primary-100 p-2 rounded-full mt-1 mr-3">
                  <SafeIcon icon={FiActivity} className="h-5 w-5 text-primary-600" />
                </div>
                <div>
                  <h4 className="font-medium text-gray-900">Pattern Recognition</h4>
                  <p className="text-gray-600">The system identifies patterns in your behavior to predict which stays you'd enjoy most.</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="bg-primary-100 p-2 rounded-full mt-1 mr-3">
                  <SafeIcon icon={FiThumbsUp} className="h-5 w-5 text-primary-600" />
                </div>
                <div>
                  <h4 className="font-medium text-gray-900">Feedback Learning</h4>
                  <p className="text-gray-600">When you provide feedback on recommendations, the AI adjusts to better match your preferences over time.</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="bg-primary-100 p-2 rounded-full mt-1 mr-3">
                  <SafeIcon icon={FiZap} className="h-5 w-5 text-primary-600" />
                </div>
                <div>
                  <h4 className="font-medium text-gray-900">Continuous Improvement</h4>
                  <p className="text-gray-600">The more you interact with the platform, the more accurate your recommendations become.</p>
                </div>
              </div>
            </div>

            <div className="mt-6 bg-gray-50 p-4 rounded-lg">
              <p className="text-sm text-gray-600">
                Your data is used only to personalize your experience and is never shared with third parties. You can reset your preferences at any time.
              </p>
            </div>

            <div className="mt-6 flex justify-end">
              <button
                onClick={() => setShowExplanation(false)}
                className="bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded-lg transition-colors"
              >
                Got It
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </section>
  );
};

export default AIRecommendations;