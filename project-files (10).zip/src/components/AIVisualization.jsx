import React, { useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import * as echarts from 'echarts/core';
import { RadarChart, PieChart } from 'echarts/charts';
import {
  TitleComponent,
  TooltipComponent,
  LegendComponent,
  GridComponent
} from 'echarts/components';
import { CanvasRenderer } from 'echarts/renderers';

// Register the components
echarts.use([
  TitleComponent,
  TooltipComponent,
  LegendComponent,
  GridComponent,
  RadarChart,
  PieChart,
  CanvasRenderer
]);

const AIVisualization = ({ userProfile }) => {
  const radarChartRef = useRef(null);
  const pieChartRef = useRef(null);
  
  // Initialize charts after component mounts
  useEffect(() => {
    // Initialize charts
    const radarChart = echarts.init(radarChartRef.current);
    const pieChart = echarts.init(pieChartRef.current);
    
    // Prepare radar chart data
    const preferences = userProfile.preferences;
    const radarData = [
      { value: calculatePreferenceScores(preferences), name: 'Your Preferences' }
    ];
    
    // Radar chart options
    const radarOption = {
      title: {
        text: 'Your Travel Profile',
        left: 'center',
        textStyle: {
          color: '#333',
          fontWeight: 'normal'
        }
      },
      tooltip: {},
      radar: {
        // Shape of radar chart
        shape: 'circle',
        indicator: [
          { name: 'Nature', max: 100 },
          { name: 'Culture', max: 100 },
          { name: 'Adventure', max: 100 },
          { name: 'Relaxation', max: 100 },
          { name: 'Luxury', max: 100 },
          { name: 'Budget', max: 100 }
        ],
        splitArea: {
          areaStyle: {
            color: ['rgba(250,250,250,0.3)', 'rgba(200,200,200,0.3)']
          }
        }
      },
      series: [{
        name: 'Travel Preferences',
        type: 'radar',
        emphasis: {
          lineStyle: {
            width: 4
          }
        },
        data: radarData,
        areaStyle: {
          opacity: 0.2
        },
        lineStyle: {
          color: '#e97441'
        },
        itemStyle: {
          color: '#e97441'
        }
      }]
    };
    
    // Prepare pie chart data for favorite locations
    const locationData = processLocationData(userProfile.favoriteLocations);
    
    // Pie chart options
    const pieOption = {
      title: {
        text: 'Your Favorite Destinations',
        left: 'center',
        textStyle: {
          color: '#333',
          fontWeight: 'normal'
        }
      },
      tooltip: {
        trigger: 'item',
        formatter: '{a} <br/>{b}: {c} ({d}%)'
      },
      legend: {
        orient: 'vertical',
        left: 'left',
        data: locationData.map(item => item.name)
      },
      series: [
        {
          name: 'Destinations',
          type: 'pie',
          radius: '65%',
          center: ['50%', '60%'],
          data: locationData,
          emphasis: {
            itemStyle: {
              shadowBlur: 10,
              shadowOffsetX: 0,
              shadowColor: 'rgba(0, 0, 0, 0.5)'
            }
          },
          itemStyle: {
            color: function(params) {
              // Custom colors
              const colors = ['#e97441', '#f4a261', '#e76f51', '#2a9d8f', '#264653'];
              return colors[params.dataIndex % colors.length];
            }
          }
        }
      ]
    };
    
    // Set chart options and render
    radarChart.setOption(radarOption);
    pieChart.setOption(pieOption);
    
    // Handle window resize
    const handleResize = () => {
      radarChart.resize();
      pieChart.resize();
    };
    window.addEventListener('resize', handleResize);
    
    // Clean up
    return () => {
      radarChart.dispose();
      pieChart.dispose();
      window.removeEventListener('resize', handleResize);
    };
  }, [userProfile]);
  
  // Calculate preference scores based on user selections
  const calculatePreferenceScores = (preferences) => {
    const baseScores = {
      'Nature': 20,
      'Culture': 20,
      'Adventure': 20,
      'Relaxation': 20,
      'Luxury': 20,
      'Budget': 20
    };
    
    // Adjust scores based on preferences
    preferences.forEach(pref => {
      if (pref === 'Nature') baseScores.Nature += 40;
      if (pref === 'Culture' || pref === 'History') baseScores.Culture += 40;
      if (pref === 'Adventure') baseScores.Adventure += 40;
      if (pref === 'Relaxation' || pref === 'Wellness') baseScores.Relaxation += 40;
      if (pref === 'Luxury') baseScores.Luxury += 40;
      if (pref === 'Budget') baseScores.Budget += 40;
      
      // Secondary influences
      if (pref === 'Photography') {
        baseScores.Nature += 20;
        baseScores.Culture += 10;
      }
      if (pref === 'Food') {
        baseScores.Culture += 20;
        baseScores.Luxury += 10;
      }
      if (pref === 'Family') {
        baseScores.Relaxation += 20;
        baseScores.Budget += 10;
      }
      if (pref === 'Romance') {
        baseScores.Luxury += 20;
        baseScores.Relaxation += 20;
      }
    });
    
    // Ensure scores don't exceed max
    Object.keys(baseScores).forEach(key => {
      baseScores[key] = Math.min(baseScores[key], 100);
    });
    
    return [
      baseScores.Nature,
      baseScores.Culture,
      baseScores.Adventure,
      baseScores.Relaxation,
      baseScores.Luxury,
      baseScores.Budget
    ];
  };
  
  // Process location data for pie chart
  const processLocationData = (locations) => {
    if (!locations || locations.length === 0) {
      return [
        { value: 1, name: 'No locations yet' }
      ];
    }
    
    // Count occurrences of each location
    const locationCounts = {};
    locations.forEach(loc => {
      locationCounts[loc] = (locationCounts[loc] || 0) + 1;
    });
    
    // Convert to array format for chart
    return Object.entries(locationCounts).map(([name, value]) => ({
      name,
      value
    }));
  };
  
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.6 }}
      className="bg-white rounded-xl shadow-lg p-6"
    >
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Radar Chart */}
        <div>
          <div ref={radarChartRef} style={{ height: '400px', width: '100%' }}></div>
        </div>
        
        {/* Pie Chart */}
        <div>
          <div ref={pieChartRef} style={{ height: '400px', width: '100%' }}></div>
        </div>
      </div>
      
      {/* Insights based on visualization */}
      <div className="mt-6 bg-gray-50 p-4 rounded-lg">
        <h4 className="font-medium text-gray-900 mb-2">AI Travel Insights</h4>
        <p className="text-gray-600 text-sm">
          Based on your profile, you seem to enjoy {getTopPreference(userProfile.preferences)} experiences. 
          Our AI suggests exploring stays in {getSuggestedLocation(userProfile)} for your next trip.
        </p>
      </div>
    </motion.div>
  );
};

// Helper function to determine top preference
const getTopPreference = (preferences) => {
  if (!preferences || preferences.length === 0) return "diverse";
  
  const preferenceGroups = {
    nature: ['Nature', 'Wildlife', 'Photography'],
    culture: ['Culture', 'History', 'Food'],
    adventure: ['Adventure', 'Unique'],
    relaxation: ['Relaxation', 'Wellness', 'Romance'],
    luxury: ['Luxury'],
    budget: ['Budget']
  };
  
  // Count matches in each group
  const counts = {
    nature: 0,
    culture: 0,
    adventure: 0,
    relaxation: 0,
    luxury: 0,
    budget: 0
  };
  
  preferences.forEach(pref => {
    Object.entries(preferenceGroups).forEach(([group, values]) => {
      if (values.includes(pref)) {
        counts[group]++;
      }
    });
  });
  
  // Find the group with highest count
  let maxCount = 0;
  let topGroup = 'diverse';
  
  Object.entries(counts).forEach(([group, count]) => {
    if (count > maxCount) {
      maxCount = count;
      topGroup = group;
    }
  });
  
  return topGroup;
};

// Helper function to suggest a location
const getSuggestedLocation = (userProfile) => {
  if (!userProfile.favoriteLocations || userProfile.favoriteLocations.length === 0) {
    // Default suggestions based on preferences
    if (userProfile.preferences.includes('Nature')) return "Norway or Costa Rica";
    if (userProfile.preferences.includes('Culture')) return "Italy or Japan";
    if (userProfile.preferences.includes('Adventure')) return "New Zealand or Chile";
    if (userProfile.preferences.includes('Relaxation')) return "Maldives or Thailand";
    if (userProfile.preferences.includes('Luxury')) return "Switzerland or Dubai";
    
    return "Italy, Japan, or Costa Rica";
  }
  
  // Return most frequent location
  const locationCounts = {};
  userProfile.favoriteLocations.forEach(loc => {
    locationCounts[loc] = (locationCounts[loc] || 0) + 1;
  });
  
  let maxCount = 0;
  let topLocation = '';
  
  Object.entries(locationCounts).forEach(([loc, count]) => {
    if (count > maxCount) {
      maxCount = count;
      topLocation = loc;
    }
  });
  
  return topLocation;
};

export default AIVisualization;