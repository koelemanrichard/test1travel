import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import * as FiIcons from 'react-icons/fi';
import SafeIcon from '../../common/SafeIcon';
import { useAdmin } from '../../contexts/AdminContext';
import supabase from '../../lib/supabase';
import ImageGalleryManager from './ImageGalleryManager';

const { FiPlus, FiEdit3, FiTrash2, FiEye, FiStar, FiMapPin, FiSearch, FiFilter, FiMoreVertical, FiImage, FiDollarSign, FiX, FiLoader, FiCheck, FiRefreshCw, FiAlertCircle, FiInfo } = FiIcons;

const AdminPropertyManager = () => {
  const [properties, setProperties] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCategory, setFilterCategory] = useState('All');
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingProperty, setEditingProperty] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    location: '',
    category: 'Treehouse',
    property_type: 'Treehouse',
    destination: 'Europe',
    location_type: 'In the countryside',
    price: '',
    description: '',
    image: '',
    images: [],
    features: [],
    accessibility: [],
    status: 'Active',
    rating: 4.5,
    guests: 2,
    bedrooms: 1,
    bathrooms: 1,
    pet_friendly: false,
    instant_book: false,
    is_featured: false,
    ai_recommended: false,
    recommendation_reason: ''
  });
  const [formError, setFormError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState(null);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [backendError, setBackendError] = useState('');

  const { isAuthenticated } = useAdmin();

  // Filter options
  const destinations = ['Europe', 'North America', 'Asia', 'Africa', 'Oceania', 'South America'];
  const propertyTypes = ['Treehouse', 'Castle', 'Modern', 'Overwater', 'Cave', 'Igloo', 'Forest Cabin', 'Wellness Retreat', 'Lighthouse', 'Houseboat', 'Dome', 'Container Home', 'Windmill', 'Barn', 'Villa', 'Lodge', 'Resort', 'Farm Stay'];
  const locationTypes = ['In a forest', 'By the water', 'In a city', 'In the mountains', 'By the beach', 'In the countryside', 'In the desert', 'In the wilderness', 'In the jungle', 'By the ocean', 'Over water', 'Underground', 'In the Arctic', 'In the savanna'];
  const features = ['WiFi', 'Kitchen', 'Pool', 'Hot Tub', 'Sauna', 'Fireplace', 'Garden', 'Pet Friendly', 'Spa', 'Restaurant', 'Beach Access', 'Ocean Views', 'City Views', 'Mountain Views', 'Wildlife Viewing', 'Stargazing', 'Historic', 'Eco-Friendly', 'Solar Power', 'Wine Tasting', 'Yoga Space', 'Art Studio', 'Farm Animals', 'Northern Lights', 'Snorkeling', 'Hiking'];
  const accessibilityOptions = ['Wheelchair Access', 'Elevator', 'Accessible Bathroom', 'Roll-in Shower', 'Grab Bars', 'Wide Doorways', 'Ramp Access', 'Accessible Parking'];

  // Fetch properties when component mounts
  useEffect(() => {
    fetchProperties();
  }, []);

  const fetchProperties = async () => {
    try {
      console.log('Fetching properties from Supabase...');
      setLoading(true);
      setBackendError('');

      const { data, error } = await supabase
        .from('properties_j293sk4l59')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching properties:', error);
        setBackendError('Failed to fetch properties from database: ' + error.message);
        setProperties([]);
      } else {
        console.log('Properties fetched successfully:', data);
        setProperties(data || []);
        setBackendError('');
      }
    } catch (error) {
      console.error('Failed to fetch properties:', error);
      setBackendError('Database connection failed: ' + error.message);
      setProperties([]);
    } finally {
      setLoading(false);
    }
  };

  const categories = [
    'All', 'Treehouse', 'Castle', 'Modern', 'Overwater', 'Cave', 'Igloo',
    'Forest Cabin', 'Wellness Retreat', 'Lighthouse', 'Houseboat', 'Dome',
    'Container Home', 'Windmill', 'Barn', 'Villa', 'Lodge', 'Resort', 'Farm Stay'
  ];

  const filteredProperties = properties.filter(property => {
    const matchesSearch = searchTerm === '' || 
      property.name?.toLowerCase().includes(searchTerm.toLowerCase()) || 
      property.location?.toLowerCase().includes(searchTerm.toLowerCase()) || 
      (property.category && property.category.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const matchesCategory = filterCategory === 'All' || property.category === filterCategory;
    
    return matchesSearch && matchesCategory;
  });

  const handleDeleteProperty = async (propertyId) => {
    setDeleteConfirm(propertyId);
  };

  const confirmDelete = async (propertyId) => {
    try {
      setIsSubmitting(true);
      console.log('Deleting property with ID:', propertyId);
      
      const { error } = await supabase
        .from('properties_j293sk4l59')
        .delete()
        .eq('id', propertyId);
        
      if (error) {
        console.error('Error deleting property:', error);
        alert('Failed to delete property: ' + error.message);
      } else {
        console.log('Property deleted successfully');
        setProperties(prevProperties => prevProperties.filter(p => p.id !== propertyId));
        alert('Property deleted successfully!');
      }
    } catch (error) {
      console.error('Property deletion error:', error);
      alert('Failed to delete property. Please try again.');
    } finally {
      setIsSubmitting(false);
      setDeleteConfirm(null);
    }
  };

  const cancelDelete = () => {
    setDeleteConfirm(null);
  };

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? checked : value
    });
    setFormError('');
  };

  const handleMultiSelectChange = (field, value) => {
    const currentValues = formData[field] || [];
    const newValues = currentValues.includes(value)
      ? currentValues.filter(v => v !== value)
      : [...currentValues, value];
    
    setFormData({
      ...formData,
      [field]: newValues
    });
  };

  const handleImagesChange = (newImages) => {
    console.log('Images updated:', newImages);
    setFormData({
      ...formData,
      images: newImages,
      // Set the primary image as well
      image: newImages.length > 0 ? newImages[0] : ''
    });
  };

  const handleEditProperty = (property) => {
    console.log('Editing property:', property);
    setEditingProperty(property);
    
    // Parse images array from database
    let imagesArray = [];
    if (property.images) {
      if (Array.isArray(property.images)) {
        imagesArray = property.images;
      } else if (typeof property.images === 'string') {
        try {
          imagesArray = JSON.parse(property.images);
        } catch (e) {
          // If parsing fails, treat as single image URL
          imagesArray = [property.images];
        }
      }
    } else if (property.image) {
      imagesArray = [property.image];
    }
    
    setFormData({
      name: property.name || '',
      location: property.location || '',
      category: property.category || 'Treehouse',
      property_type: property.property_type || property.category || 'Treehouse',
      destination: property.destination || 'Europe',
      location_type: property.location_type || 'In the countryside',
      price: property.price?.toString() || '',
      description: property.description || '',
      image: property.image || '',
      images: imagesArray,
      features: Array.isArray(property.features) ? property.features : [],
      accessibility: Array.isArray(property.accessibility) ? property.accessibility : [],
      status: property.status || 'Active',
      rating: property.rating || 4.5,
      guests: property.guests || 2,
      bedrooms: property.bedrooms || 1,
      bathrooms: property.bathrooms || 1,
      pet_friendly: property.pet_friendly || false,
      instant_book: property.instant_book || false,
      is_featured: property.is_featured || false,
      ai_recommended: property.ai_recommended || false,
      recommendation_reason: property.recommendation_reason || ''
    });
    
    setShowAddModal(true);
    setFormError('');
    setSubmitSuccess(false);
  };

  const handleAddNewProperty = () => {
    setEditingProperty(null);
    setFormData({
      name: '',
      location: '',
      category: 'Treehouse',
      property_type: 'Treehouse',
      destination: 'Europe',
      location_type: 'In the countryside',
      price: '',
      description: '',
      image: '',
      images: [],
      features: [],
      accessibility: [],
      status: 'Active',
      rating: 4.5,
      guests: 2,
      bedrooms: 1,
      bathrooms: 1,
      pet_friendly: false,
      instant_book: false,
      is_featured: false,
      ai_recommended: false,
      recommendation_reason: ''
    });
    setShowAddModal(true);
    setFormError('');
    setSubmitSuccess(false);
  };

  const validateForm = () => {
    if (!formData.name?.trim() || !formData.location?.trim() || !formData.price || !formData.category) {
      setFormError('Please fill in all required fields (Name, Location, Category, and Price)');
      return false;
    }
    
    const priceValue = parseFloat(formData.price);
    if (isNaN(priceValue) || priceValue <= 0) {
      setFormError('Price must be a positive number');
      return false;
    }
    
    const ratingValue = parseFloat(formData.rating);
    if (isNaN(ratingValue) || ratingValue < 0 || ratingValue > 5) {
      setFormError('Rating must be between 0 and 5');
      return false;
    }

    if (formData.ai_recommended && !formData.recommendation_reason.trim()) {
      setFormError('Please provide a recommendation reason for AI recommended properties');
      return false;
    }
    
    setFormError('');
    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;
    
    setIsSubmitting(true);
    setSubmitSuccess(false);
    setFormError('');
    
    try {
      const priceValue = parseFloat(formData.price);
      const ratingValue = parseFloat(formData.rating);
      
      const propertyData = {
        name: formData.name.trim(),
        location: formData.location.trim(),
        category: formData.category,
        property_type: formData.property_type,
        destination: formData.destination,
        location_type: formData.location_type,
        price: priceValue,
        description: formData.description?.trim() || null,
        image: formData.images.length > 0 ? formData.images[0] : null,
        images: formData.images,
        features: formData.features,
        accessibility: formData.accessibility,
        status: formData.status,
        rating: ratingValue,
        guests: parseInt(formData.guests),
        bedrooms: parseInt(formData.bedrooms),
        bathrooms: parseInt(formData.bathrooms),
        pet_friendly: formData.pet_friendly,
        instant_book: formData.instant_book,
        is_featured: formData.is_featured,
        ai_recommended: formData.ai_recommended,
        recommendation_reason: formData.ai_recommended ? formData.recommendation_reason.trim() : null,
        updated_at: new Date().toISOString()
      };
      
      if (editingProperty) {
        console.log('Updating property:', editingProperty.id);
        const { data, error } = await supabase
          .from('properties_j293sk4l59')
          .update(propertyData)
          .eq('id', editingProperty.id)
          .select();
          
        if (error) {
          console.error('Update error:', error);
          setFormError(`Failed to update property: ${error.message}`);
          return;
        }
        
        console.log('Update successful:', data);
        
        // Update local state
        const updatedProperty = data && data.length > 0 ? data[0] : {...editingProperty, ...propertyData};
        setProperties(prevProperties => 
          prevProperties.map(p => p.id === editingProperty.id ? updatedProperty : p)
        );
        
        setSubmitSuccess(true);
        
        // Close modal after showing success
        setTimeout(() => {
          setShowAddModal(false);
          setEditingProperty(null);
          resetForm();
        }, 2000);
      } else {
        console.log('Creating new property with data:', propertyData);
        
        // Add new property
        const { data, error } = await supabase
          .from('properties_j293sk4l59')
          .insert([{...propertyData, created_at: new Date().toISOString()}])
          .select();
          
        if (error) {
          console.error('Error creating property:', error);
          setFormError('Failed to create property: ' + (error.message || 'Unknown error'));
          return;
        }
        
        console.log('Property created successfully, returned data:', data);
        
        // Add to local state
        if (data && data.length > 0) {
          setProperties(prevProperties => [data[0], ...prevProperties]);
        }
        
        setSubmitSuccess(true);
        
        // Close modal after showing success
        setTimeout(() => {
          setShowAddModal(false);
          resetForm();
        }, 2000);

        // Update category counts if it's a new property
        if (formData.category) {
          updateCategoryCount(formData.category);
        }
      }
    } catch (error) {
      console.error('Form submission error:', error);
      setFormError('An unexpected error occurred: ' + (error.message || 'Please try again'));
    } finally {
      setIsSubmitting(false);
    }
  };

  // Update category count when adding new property
  const updateCategoryCount = async (category) => {
    try {
      // Check if category exists
      const { data: existingCategory, error: checkError } = await supabase
        .from('categories_j293sk4l59')
        .select('count')
        .eq('name', category)
        .single();
        
      if (checkError && checkError.code !== 'PGRST116') {
        console.error('Error checking category:', checkError);
        return;
      }
      
      if (existingCategory) {
        // Update count
        const { error: updateError } = await supabase
          .from('categories_j293sk4l59')
          .update({ count: existingCategory.count + 1 })
          .eq('name', category);
          
        if (updateError) {
          console.error('Error updating category count:', updateError);
        }
      } else {
        // Create new category
        const { error: insertError } = await supabase
          .from('categories_j293sk4l59')
          .insert([{
            name: category,
            count: 1,
            image: 'https://images.unsplash.com/photo-1571896349842-33c89424de2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80'
          }]);
          
        if (insertError) {
          console.error('Error creating new category:', insertError);
        }
      }
    } catch (error) {
      console.error('Error updating category counts:', error);
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      location: '',
      category: 'Treehouse',
      property_type: 'Treehouse',
      destination: 'Europe',
      location_type: 'In the countryside',
      price: '',
      description: '',
      image: '',
      images: [],
      features: [],
      accessibility: [],
      status: 'Active',
      rating: 4.5,
      guests: 2,
      bedrooms: 1,
      bathrooms: 1,
      pet_friendly: false,
      instant_book: false,
      is_featured: false,
      ai_recommended: false,
      recommendation_reason: ''
    });
    setSubmitSuccess(false);
    setFormError('');
  };

  const handleCloseModal = () => {
    setShowAddModal(false);
    setEditingProperty(null);
    resetForm();
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'Active': return 'bg-green-100 text-green-800';
      case 'Inactive': return 'bg-red-100 text-red-800';
      case 'Pending': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const handleImageError = (e) => {
    if (e.target.src !== 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTUwIiBoZWlnaHQ9IjE1MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZGRkIi8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCIgZm9udC1zaXplPSIxNCIgZmlsbD0iIzk5OSIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPk5vIEltYWdlPC90ZXh0Pjwvc3ZnPg==') {
      e.target.src = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTUwIiBoZWlnaHQ9IjE1MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZGRkIi8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCIgZm9udC1zaXplPSIxNCIgZmlsbD0iIzk5OSIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPk5vIEltYWdlPC90ZXh0Pjwvc3ZnPg==';
    }
  };

  // Helper function to get image count display
  const getImageCountDisplay = (property) => {
    let imageCount = 0;
    if (property.images) {
      if (Array.isArray(property.images)) {
        imageCount = property.images.length;
      } else if (typeof property.images === 'string') {
        try {
          const parsed = JSON.parse(property.images);
          imageCount = Array.isArray(parsed) ? parsed.length : 1;
        } catch (e) {
          imageCount = 1; // Treat as single image URL
        }
      }
    } else if (property.image) {
      imageCount = 1;
    }
    return imageCount;
  };

  // Helper function to get primary image
  const getPrimaryImage = (property) => {
    if (property.images) {
      if (Array.isArray(property.images) && property.images.length > 0) {
        return property.images[0];
      } else if (typeof property.images === 'string') {
        try {
          const parsed = JSON.parse(property.images);
          return Array.isArray(parsed) && parsed.length > 0 ? parsed[0] : property.image;
        } catch (e) {
          return property.images; // Treat as single image URL
        }
      }
    }
    return property.image || 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTUwIiBoZWlnaHQ9IjE1MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZGRkIi8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCIgZm9udC1zaXplPSIxNCIgZmlsbD0iIzk5OSIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPk5vIEltYWdlPC90ZXh0Pjwvc3ZnPg==';
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/4 mb-4"></div>
          <div className="h-12 bg-gray-200 rounded mb-6"></div>
          <div className="space-y-4">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="h-20 bg-gray-200 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center space-y-4 sm:space-y-0">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Property Management</h1>
          <p className="text-gray-600 mt-1">Manage all unique stays and accommodations</p>
        </div>
        <button
          onClick={handleAddNewProperty}
          className="bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded-lg flex items-center space-x-2 transition-colors"
        >
          <SafeIcon icon={FiPlus} className="h-5 w-5" />
          <span>Add Property</span>
        </button>
      </div>

      {/* Backend Error Alert */}
      {backendError && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg flex items-center">
          <SafeIcon icon={FiAlertCircle} className="h-5 w-5 mr-2" />
          <span>{backendError}</span>
          <button onClick={fetchProperties} className="ml-auto text-red-600 hover:text-red-800">
            <SafeIcon icon={FiRefreshCw} className="h-4 w-4" />
          </button>
        </div>
      )}

      {/* Connection Status */}
      <div className="bg-blue-50 border border-blue-200 text-blue-700 px-4 py-3 rounded-lg flex items-center">
        <SafeIcon icon={FiInfo} className="h-5 w-5 mr-2" />
        <span>
          Database Status: {backendError ? 'Connection Error' : 'Connected'} | Properties Loaded: {properties.length}
        </span>
      </div>

      {/* Filters */}
      <div className="bg-white p-4 rounded-lg shadow-sm space-y-4 sm:space-y-0 sm:flex sm:items-center sm:justify-between">
        <div className="flex-1 max-w-md">
          <div className="relative">
            <SafeIcon
              icon={FiSearch}
              className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400"
            />
            <input
              type="text"
              placeholder="Search properties..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
            />
          </div>
        </div>
        <div className="flex items-center space-x-4">
          <select
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value)}
            className="border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-primary-500 focus:border-transparent"
          >
            {categories.map(category => (
              <option key={category} value={category}>{category}</option>
            ))}
          </select>
          <button
            onClick={fetchProperties}
            className="bg-gray-100 hover:bg-gray-200 text-gray-700 px-3 py-2 rounded-lg transition-colors flex items-center space-x-1"
            title="Refresh data"
          >
            <SafeIcon icon={FiRefreshCw} className="h-5 w-5" />
            <span>Refresh</span>
          </button>
        </div>
      </div>

      {/* Properties List */}
      <div className="bg-white rounded-lg shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Property
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Type & Location
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Price & Rating
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Details
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredProperties.map((property) => (
                <motion.tr
                  key={property.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="hover:bg-gray-50"
                >
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="relative h-12 w-12 rounded-lg overflow-hidden">
                        <img
                          src={getPrimaryImage(property)}
                          alt={property.name}
                          className="h-full w-full object-cover"
                          onError={handleImageError}
                        />
                        {getImageCountDisplay(property) > 1 && (
                          <div className="absolute bottom-0 right-0 bg-black bg-opacity-60 text-white text-xs px-1 rounded-tl">
                            +{getImageCountDisplay(property) - 1}
                          </div>
                        )}
                      </div>
                      <div className="ml-4">
                        <div className="text-sm font-medium text-gray-900">{property.name}</div>
                        <div className="text-sm text-gray-500 flex items-center">
                          <SafeIcon icon={FiMapPin} className="h-3 w-3 mr-1" />
                          {property.location}
                        </div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">{property.property_type || property.category}</div>
                    <div className="text-sm text-gray-500">{property.location_type}</div>
                    <div className="text-sm text-gray-500">{property.destination}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">€{property.price}/night</div>
                    <div className="flex items-center">
                      <SafeIcon icon={FiStar} className="h-4 w-4 text-yellow-400 fill-current mr-1" />
                      <span className="text-sm font-medium text-gray-700">{property.rating || 'N/A'}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">{property.guests} guests</div>
                    <div className="text-sm text-gray-500">{property.bedrooms} bed, {property.bathrooms} bath</div>
                    <div className="flex space-x-1 mt-1">
                      {property.pet_friendly && (
                        <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-green-100 text-green-800">
                          Pet Friendly
                        </span>
                      )}
                      {property.instant_book && (
                        <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-blue-100 text-blue-800">
                          Instant Book
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(property.status)}`}>
                      {property.status || 'Active'}
                    </span>
                    <div className="flex space-x-1 mt-2">
                      {property.is_featured && (
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                          Featured
                        </span>
                      )}
                      {property.ai_recommended && (
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
                          AI Recommended
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <div className="flex items-center justify-end space-x-2">
                      <button className="text-gray-400 hover:text-primary-600">
                        <SafeIcon icon={FiEye} className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() => handleEditProperty(property)}
                        className="text-gray-400 hover:text-primary-600"
                      >
                        <SafeIcon icon={FiEdit3} className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() => handleDeleteProperty(property.id)}
                        className="text-gray-400 hover:text-red-600"
                      >
                        <SafeIcon icon={FiTrash2} className="h-4 w-4" />
                      </button>
                    </div>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Empty State */}
      {filteredProperties.length === 0 && (
        <div className="text-center py-12">
          <SafeIcon icon={FiImage} className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No properties found</h3>
          <p className="text-gray-500">
            {backendError ? 'Unable to load properties due to connection error.' : 'Try adjusting your search or filter criteria.'}
          </p>
        </div>
      )}

      {/* Add/Edit Property Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.3 }}
            className="bg-white rounded-lg p-6 max-w-6xl w-full mx-4 max-h-[90vh] overflow-y-auto"
          >
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-2xl font-semibold text-gray-900">
                {editingProperty ? 'Edit Property' : 'Add New Property'}
              </h3>
              <button onClick={handleCloseModal} className="text-gray-400 hover:text-gray-600">
                <SafeIcon icon={FiX} className="h-6 w-6" />
              </button>
            </div>

            {formError && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-6">
                {formError}
              </div>
            )}

            {submitSuccess && (
              <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg mb-6 flex items-center">
                <SafeIcon icon={FiCheck} className="h-5 w-5 mr-2" />
                {editingProperty ? 'Property updated successfully!' : 'Property created successfully!'}
              </div>
            )}

            <form onSubmit={handleSubmit}>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
                {/* Basic Information */}
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                    Property Name*
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    required
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                    placeholder="Enter property name"
                  />
                </div>
                <div>
                  <label htmlFor="location" className="block text-sm font-medium text-gray-700 mb-1">
                    Location*
                  </label>
                  <input
                    type="text"
                    id="location"
                    name="location"
                    value={formData.location}
                    onChange={handleInputChange}
                    required
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                    placeholder="Enter location"
                  />
                </div>
                <div>
                  <label htmlFor="price" className="block text-sm font-medium text-gray-700 mb-1">
                    Price per Night (€)*
                  </label>
                  <input
                    type="number"
                    id="price"
                    name="price"
                    value={formData.price}
                    onChange={handleInputChange}
                    required
                    min="1"
                    step="0.01"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                    placeholder="Enter price"
                  />
                </div>

                {/* Categories and Types */}
                <div>
                  <label htmlFor="category" className="block text-sm font-medium text-gray-700 mb-1">
                    Category*
                  </label>
                  <select
                    id="category"
                    name="category"
                    value={formData.category}
                    onChange={handleInputChange}
                    required
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                  >
                    {propertyTypes.map(type => (
                      <option key={type} value={type}>{type}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label htmlFor="property_type" className="block text-sm font-medium text-gray-700 mb-1">
                    Property Type
                  </label>
                  <select
                    id="property_type"
                    name="property_type"
                    value={formData.property_type}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                  >
                    {propertyTypes.map(type => (
                      <option key={type} value={type}>{type}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label htmlFor="destination" className="block text-sm font-medium text-gray-700 mb-1">
                    Destination
                  </label>
                  <select
                    id="destination"
                    name="destination"
                    value={formData.destination}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                  >
                    {destinations.map(dest => (
                      <option key={dest} value={dest}>{dest}</option>
                    ))}
                  </select>
                </div>

                {/* Location and Details */}
                <div>
                  <label htmlFor="location_type" className="block text-sm font-medium text-gray-700 mb-1">
                    Location Type
                  </label>
                  <select
                    id="location_type"
                    name="location_type"
                    value={formData.location_type}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                  >
                    {locationTypes.map(locType => (
                      <option key={locType} value={locType}>{locType}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label htmlFor="guests" className="block text-sm font-medium text-gray-700 mb-1">
                    Max Guests
                  </label>
                  <input
                    type="number"
                    id="guests"
                    name="guests"
                    value={formData.guests}
                    onChange={handleInputChange}
                    min="1"
                    max="20"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label htmlFor="rating" className="block text-sm font-medium text-gray-700 mb-1">
                    Rating (0-5)
                  </label>
                  <input
                    type="number"
                    id="rating"
                    name="rating"
                    value={formData.rating}
                    onChange={handleInputChange}
                    min="0"
                    max="5"
                    step="0.1"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                  />
                </div>

                {/* Room Details */}
                <div>
                  <label htmlFor="bedrooms" className="block text-sm font-medium text-gray-700 mb-1">
                    Bedrooms
                  </label>
                  <input
                    type="number"
                    id="bedrooms"
                    name="bedrooms"
                    value={formData.bedrooms}
                    onChange={handleInputChange}
                    min="1"
                    max="10"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label htmlFor="bathrooms" className="block text-sm font-medium text-gray-700 mb-1">
                    Bathrooms
                  </label>
                  <input
                    type="number"
                    id="bathrooms"
                    name="bathrooms"
                    value={formData.bathrooms}
                    onChange={handleInputChange}
                    min="1"
                    max="10"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label htmlFor="status" className="block text-sm font-medium text-gray-700 mb-1">
                    Status
                  </label>
                  <select
                    id="status"
                    name="status"
                    value={formData.status}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                  >
                    <option value="Active">Active</option>
                    <option value="Inactive">Inactive</option>
                    <option value="Pending">Pending</option>
                  </select>
                </div>
              </div>

              {/* Description */}
              <div className="mb-6">
                <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">
                  Description
                </label>
                <textarea
                  id="description"
                  name="description"
                  value={formData.description}
                  onChange={handleInputChange}
                  rows="4"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                  placeholder="Enter property description"
                ></textarea>
              </div>

              {/* Features */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">Features</label>
                <div className="grid grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2 max-h-32 overflow-y-auto border border-gray-300 rounded-lg p-3">
                  {features.map(feature => (
                    <label key={feature} className="flex items-center space-x-2 text-sm">
                      <input
                        type="checkbox"
                        checked={formData.features.includes(feature)}
                        onChange={() => handleMultiSelectChange('features', feature)}
                        className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                      />
                      <span>{feature}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Accessibility */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">Accessibility Features</label>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2 max-h-32 overflow-y-auto border border-gray-300 rounded-lg p-3">
                  {accessibilityOptions.map(accessibility => (
                    <label key={accessibility} className="flex items-center space-x-2 text-sm">
                      <input
                        type="checkbox"
                        checked={formData.accessibility.includes(accessibility)}
                        onChange={() => handleMultiSelectChange('accessibility', accessibility)}
                        className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                      />
                      <span>{accessibility}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Toggles */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-6">
                <div>
                  <label className="flex items-center space-x-2 text-sm font-medium text-gray-700">
                    <input
                      type="checkbox"
                      name="pet_friendly"
                      checked={formData.pet_friendly}
                      onChange={handleInputChange}
                      className="rounded border-gray-300 text-primary-600 focus:ring-primary-500 h-4 w-4"
                    />
                    <span>Pet Friendly</span>
                  </label>
                </div>
                <div>
                  <label className="flex items-center space-x-2 text-sm font-medium text-gray-700">
                    <input
                      type="checkbox"
                      name="instant_book"
                      checked={formData.instant_book}
                      onChange={handleInputChange}
                      className="rounded border-gray-300 text-primary-600 focus:ring-primary-500 h-4 w-4"
                    />
                    <span>Instant Book</span>
                  </label>
                </div>
                <div>
                  <label className="flex items-center space-x-2 text-sm font-medium text-gray-700">
                    <input
                      type="checkbox"
                      name="is_featured"
                      checked={formData.is_featured}
                      onChange={handleInputChange}
                      className="rounded border-gray-300 text-primary-600 focus:ring-primary-500 h-4 w-4"
                    />
                    <span>Featured Property</span>
                  </label>
                </div>
                <div>
                  <label className="flex items-center space-x-2 text-sm font-medium text-gray-700">
                    <input
                      type="checkbox"
                      name="ai_recommended"
                      checked={formData.ai_recommended}
                      onChange={handleInputChange}
                      className="rounded border-gray-300 text-primary-600 focus:ring-primary-500 h-4 w-4"
                    />
                    <span>AI Recommended</span>
                  </label>
                </div>
              </div>

              {/* AI Recommendation Reason */}
              {formData.ai_recommended && (
                <div className="mb-6">
                  <label htmlFor="recommendation_reason" className="block text-sm font-medium text-gray-700 mb-1">
                    Recommendation Reason*
                  </label>
                  <input
                    type="text"
                    id="recommendation_reason"
                    name="recommendation_reason"
                    value={formData.recommendation_reason}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                    placeholder="e.g., Based on your Nature preference"
                    required={formData.ai_recommended}
                  />
                </div>
              )}

              {/* Image Gallery Manager */}
              <div className="mb-6">
                <ImageGalleryManager
                  propertyId={editingProperty?.id}
                  initialImages={formData.images}
                  onImagesChange={handleImagesChange}
                />
              </div>

              <div className="mt-8 flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={handleCloseModal}
                  className="px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting || submitSuccess}
                  className="flex items-center px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors disabled:bg-primary-400"
                >
                  {isSubmitting && (
                    <SafeIcon icon={FiLoader} className="h-4 w-4 mr-2 animate-spin" />
                  )}
                  {submitSuccess ? (
                    <>
                      <SafeIcon icon={FiCheck} className="h-4 w-4 mr-2" />
                      {editingProperty ? 'Updated!' : 'Added!'}
                    </>
                  ) : (
                    editingProperty ? 'Update Property' : 'Add Property'
                  )}
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.3 }}
            className="bg-white rounded-lg p-6 max-w-md w-full mx-4"
          >
            <h3 className="text-xl font-semibold text-gray-900 mb-4">Confirm Deletion</h3>
            <p className="text-gray-700 mb-6">
              Are you sure you want to delete this property? This action cannot be undone.
            </p>
            <div className="flex justify-end space-x-3">
              <button
                onClick={cancelDelete}
                className="px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => confirmDelete(deleteConfirm)}
                disabled={isSubmitting}
                className="flex items-center px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors disabled:bg-red-400"
              >
                {isSubmitting && (
                  <SafeIcon icon={FiLoader} className="h-4 w-4 mr-2 animate-spin" />
                )}
                Delete Property
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
};

export default AdminPropertyManager;