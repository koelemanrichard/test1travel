import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import * as FiIcons from 'react-icons/fi';
import SafeIcon from '../../common/SafeIcon';
import supabase from '../../lib/supabase';

const { FiDatabase, FiUpload, FiTrash2, FiAlertCircle, FiCheckCircle, FiLoader, FiInfo, FiRefreshCw, FiX, FiPlusCircle } = FiIcons;

const DatabaseImport = () => {
  const [importing, setImporting] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [addingMore, setAddingMore] = useState(false);
  const [success, setSuccess] = useState(null);
  const [error, setError] = useState(null);
  const [stats, setStats] = useState(null);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [operation, setOperation] = useState(null); // 'import', 'delete', or 'add-more'
  const [loadingStats, setLoadingStats] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState('checking');

  // Check database connection when component mounts
  useEffect(() => {
    checkConnection();
  }, []);

  // Check if we can connect to Supabase
  const checkConnection = async () => {
    try {
      setConnectionStatus('checking');
      
      // Simple test query to check connection
      const { data, error } = await supabase
        .from('properties_j293sk4l59')
        .select('id')
        .limit(1);
      
      if (error) {
        if (error.code === 'PGRST116' || error.message.includes('does not exist')) {
          console.log('Supabase connection successful - tables not yet created');
          setConnectionStatus('connected');
          setError(null);
          // Set empty stats since tables don't exist yet
          setStats({
            properties_j293sk4l59: 0,
            categories_j293sk4l59: 0,
            users_j293sk4l59: 0,
            bookings_j293sk4l59: 0
          });
        } else {
          console.error('Supabase connection test failed:', error);
          setConnectionStatus('error');
          setError('Failed to connect to Supabase database: ' + error.message);
        }
      } else {
        console.log('Supabase connection successful');
        setConnectionStatus('connected');
        setError(null);
        // Once connection is confirmed, fetch stats
        fetchDatabaseStats();
      }
    } catch (error) {
      console.error('Supabase connection error:', error);
      setConnectionStatus('error');
      setError('Database connection error: ' + error.message);
    }
  };

  // Fetch current database stats
  const fetchDatabaseStats = async () => {
    if (connectionStatus !== 'connected') {
      return;
    }
    
    setLoadingStats(true);
    setError(null);
    
    try {
      const statsData = {};
      const tables = ['properties_j293sk4l59', 'categories_j293sk4l59', 'users_j293sk4l59', 'bookings_j293sk4l59'];
      
      for (const tableName of tables) {
        try {
          const { count, error } = await supabase
            .from(tableName)
            .select('*', { count: 'exact', head: true });
          
          if (error) {
            console.error(`Error counting ${tableName}:`, error);
            statsData[tableName] = 0;
          } else {
            statsData[tableName] = count || 0;
          }
        } catch (tableError) {
          console.error(`Error accessing ${tableName}:`, tableError);
          statsData[tableName] = 0;
        }
      }
      
      setStats(statsData);
    } catch (error) {
      console.error('Error fetching database stats:', error);
      setError('Failed to fetch database statistics');
    } finally {
      setLoadingStats(false);
    }
  };

  // Execute SQL using supabase.rpc
  const executeSQLCommand = async (sqlCommand) => {
    try {
      const { data, error } = await supabase.rpc('exec_sql', {
        sql: sqlCommand
      });
      
      if (error) {
        console.error('SQL execution error:', error);
        return { success: false, error };
      }
      
      console.log('SQL executed successfully:', sqlCommand.substring(0, 50) + '...');
      return { success: true, data };
    } catch (error) {
      console.error('Error executing SQL:', error);
      return { success: false, error };
    }
  };

  // Step 1: Create tables with proper structure
  const createTables = async () => {
    try {
      console.log('Creating database tables...');

      // Create all tables in one SQL command
      const createTablesSQL = `
        -- Drop existing tables to start fresh
        DROP TABLE IF EXISTS bookings_j293sk4l59 CASCADE;
        DROP TABLE IF EXISTS properties_j293sk4l59 CASCADE;
        DROP TABLE IF EXISTS users_j293sk4l59 CASCADE;
        DROP TABLE IF EXISTS categories_j293sk4l59 CASCADE;

        -- Create properties table
        CREATE TABLE properties_j293sk4l59 (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          name TEXT NOT NULL,
          location TEXT NOT NULL,
          category TEXT,
          property_type TEXT,
          destination TEXT,
          location_type TEXT,
          price NUMERIC(10,2) CHECK (price >= 0),
          description TEXT,
          image TEXT,
          images TEXT[], -- Array of image URLs
          features TEXT[], -- Array of features
          accessibility TEXT[], -- Array of accessibility options
          rating NUMERIC(3,1),
          guests INTEGER,
          bedrooms INTEGER,
          bathrooms INTEGER,
          pet_friendly BOOLEAN DEFAULT false,
          instant_book BOOLEAN DEFAULT false,
          is_featured BOOLEAN DEFAULT false,
          ai_recommended BOOLEAN DEFAULT false,
          recommendation_reason TEXT,
          status TEXT DEFAULT 'Active',
          created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
        );

        -- Create categories table
        CREATE TABLE categories_j293sk4l59 (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          name TEXT NOT NULL,
          image TEXT,
          count INTEGER DEFAULT 0,
          created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
        );

        -- Create users table
        CREATE TABLE users_j293sk4l59 (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          name TEXT NOT NULL,
          email TEXT NOT NULL UNIQUE,
          status TEXT DEFAULT 'Active',
          join_date DATE DEFAULT CURRENT_DATE,
          last_login TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
          bookings INTEGER DEFAULT 0,
          total_spent NUMERIC(10,2) DEFAULT 0,
          location TEXT,
          created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
        );

        -- Create bookings table
        CREATE TABLE bookings_j293sk4l59 (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          guest_name TEXT NOT NULL,
          guest_email TEXT NOT NULL,
          property_name TEXT NOT NULL,
          property_location TEXT NOT NULL,
          check_in DATE NOT NULL,
          check_out DATE NOT NULL,
          guests INTEGER NOT NULL,
          total_amount NUMERIC(10,2) NOT NULL,
          status TEXT DEFAULT 'Pending',
          booking_date DATE DEFAULT CURRENT_DATE,
          payment_status TEXT DEFAULT 'Pending',
          created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
        );

        -- Enable RLS on all tables
        ALTER TABLE properties_j293sk4l59 ENABLE ROW LEVEL SECURITY;
        ALTER TABLE categories_j293sk4l59 ENABLE ROW LEVEL SECURITY;
        ALTER TABLE users_j293sk4l59 ENABLE ROW LEVEL SECURITY;
        ALTER TABLE bookings_j293sk4l59 ENABLE ROW LEVEL SECURITY;

        -- Create policies for public access
        CREATE POLICY "Allow public read access" ON properties_j293sk4l59 FOR SELECT USING (true);
        CREATE POLICY "Allow public insert" ON properties_j293sk4l59 FOR INSERT WITH CHECK (true);
        CREATE POLICY "Allow public update" ON properties_j293sk4l59 FOR UPDATE USING (true);
        CREATE POLICY "Allow public delete" ON properties_j293sk4l59 FOR DELETE USING (true);

        CREATE POLICY "Allow public read access" ON categories_j293sk4l59 FOR SELECT USING (true);
        CREATE POLICY "Allow public insert" ON categories_j293sk4l59 FOR INSERT WITH CHECK (true);
        CREATE POLICY "Allow public update" ON categories_j293sk4l59 FOR UPDATE USING (true);
        CREATE POLICY "Allow public delete" ON categories_j293sk4l59 FOR DELETE USING (true);

        CREATE POLICY "Allow public read access" ON users_j293sk4l59 FOR SELECT USING (true);
        CREATE POLICY "Allow public insert" ON users_j293sk4l59 FOR INSERT WITH CHECK (true);
        CREATE POLICY "Allow public update" ON users_j293sk4l59 FOR UPDATE USING (true);
        CREATE POLICY "Allow public delete" ON users_j293sk4l59 FOR DELETE USING (true);

        CREATE POLICY "Allow public read access" ON bookings_j293sk4l59 FOR SELECT USING (true);
        CREATE POLICY "Allow public insert" ON bookings_j293sk4l59 FOR INSERT WITH CHECK (true);
        CREATE POLICY "Allow public update" ON bookings_j293sk4l59 FOR UPDATE USING (true);
        CREATE POLICY "Allow public delete" ON bookings_j293sk4l59 FOR DELETE USING (true);
      `;

      const result = await executeSQLCommand(createTablesSQL);
      
      if (!result.success) {
        console.error('Error creating tables:', result.error);
        return false;
      }

      console.log('All tables created successfully');
      return true;
    } catch (error) {
      console.error('Error in createTables:', error);
      return false;
    }
  };

  // Step 2: Insert sample data using SQL
  const insertSampleData = async () => {
    try {
      console.log('Inserting sample data...');

      const insertDataSQL = `
        -- Insert categories
        INSERT INTO categories_j293sk4l59 (name, image, count) VALUES
        ('Treehouses', 'https://images.unsplash.com/photo-1571896349842-33c89424de2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80', 1),
        ('Castles', 'https://images.unsplash.com/photo-1520637736862-4d197d17c92a?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80', 1),
        ('Modern', 'https://images.unsplash.com/photo-1582719508461-905c673771fd?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80', 1),
        ('Overwater', 'https://images.unsplash.com/photo-1559827260-dc66d52bef19?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80', 1);

        -- Insert properties with proper array syntax
        INSERT INTO properties_j293sk4l59 (
          name, location, category, property_type, destination, location_type,
          price, description, image, images, features, accessibility,
          rating, guests, bedrooms, bathrooms, pet_friendly, instant_book,
          is_featured, ai_recommended, recommendation_reason
        ) VALUES
        (
          'Canopy Paradise Treehouse',
          'Costa Rica Rainforest',
          'Treehouse',
          'Treehouse',
          'North America',
          'In a forest',
          185,
          'Sleep among the treetops in this eco-luxury treehouse with panoramic rainforest views.',
          'https://images.unsplash.com/photo-1571896349842-33c89424de2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
          ARRAY['https://images.unsplash.com/photo-1571896349842-33c89424de2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
          ARRAY['WiFi', 'Kitchen', 'Wildlife Viewing', 'Eco-Friendly', 'Stargazing'],
          ARRAY[]::TEXT[],
          4.9,
          2,
          1,
          1,
          false,
          true,
          true,
          true,
          'Perfect for nature lovers seeking adventure'
        ),
        (
          'Highland Castle Keep',
          'Scottish Highlands, Scotland',
          'Castle',
          'Castle',
          'Europe',
          'In the mountains',
          450,
          '16th-century castle with authentic medieval features and modern luxury amenities.',
          'https://images.unsplash.com/photo-1520637736862-4d197d17c92a?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
          ARRAY['https://images.unsplash.com/photo-1520637736862-4d197d17c92a?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
          ARRAY['WiFi', 'Fireplace', 'Kitchen', 'Historic', 'Garden', 'Wine Tasting'],
          ARRAY[]::TEXT[],
          4.8,
          8,
          4,
          3,
          false,
          false,
          true,
          false,
          null
        ),
        (
          'Desert Glass House',
          'Sahara Desert, Morocco',
          'Modern',
          'Modern',
          'Africa',
          'In the desert',
          320,
          'A stunning glass house offering unobstructed views of the Sahara Desert and incredible stargazing opportunities.',
          'https://images.unsplash.com/photo-1582719508461-905c673771fd?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
          ARRAY['https://images.unsplash.com/photo-1582719508461-905c673771fd?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
          ARRAY['WiFi', 'Kitchen', 'Stargazing', 'Desert Views', 'Solar Power'],
          ARRAY[]::TEXT[],
          4.7,
          4,
          2,
          2,
          false,
          true,
          true,
          true,
          'Unique desert experience with modern amenities'
        ),
        (
          'Floating Villa Maldives',
          'Baa Atoll, Maldives',
          'Overwater',
          'Villa',
          'Asia',
          'Over water',
          680,
          'Luxury overwater villa with direct access to crystal-clear lagoon waters and coral reefs.',
          'https://images.unsplash.com/photo-1559827260-dc66d52bef19?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
          ARRAY['https://images.unsplash.com/photo-1559827260-dc66d52bef19?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
          ARRAY['WiFi', 'Ocean Views', 'Snorkeling', 'Private Deck', 'Spa'],
          ARRAY[]::TEXT[],
          5.0,
          2,
          1,
          1,
          false,
          true,
          true,
          true,
          'Ultimate luxury overwater experience'
        );

        -- Insert users
        INSERT INTO users_j293sk4l59 (name, email, status, join_date, last_login, bookings, total_spent, location) VALUES
        ('Sarah Johnson', 'sarah.johnson@email.com', 'Active', '2024-01-15', '2024-03-10', 5, 2450, 'New York, USA'),
        ('John Smith', 'john.smith@email.com', 'Active', '2024-02-10', '2024-03-15', 3, 1560, 'London, UK'),
        ('Maria Garcia', 'maria.garcia@email.com', 'Active', '2024-01-20', '2024-03-05', 2, 980, 'Barcelona, Spain'),
        ('David Chen', 'david.chen@email.com', 'Active', '2024-02-01', '2024-03-12', 4, 1850, 'Toronto, Canada');

        -- Insert bookings
        INSERT INTO bookings_j293sk4l59 (
          guest_name, guest_email, property_name, property_location,
          check_in, check_out, guests, total_amount, status, booking_date, payment_status
        ) VALUES
        ('Sarah Johnson', 'sarah.johnson@email.com', 'Canopy Paradise Treehouse', 'Costa Rica Rainforest', '2024-04-15', '2024-04-18', 2, 555, 'Confirmed', '2024-03-10', 'Paid'),
        ('John Smith', 'john.smith@email.com', 'Highland Castle Keep', 'Scottish Highlands, Scotland', '2024-05-20', '2024-05-25', 4, 2250, 'Confirmed', '2024-03-15', 'Paid'),
        ('Maria Garcia', 'maria.garcia@email.com', 'Desert Glass House', 'Sahara Desert, Morocco', '2024-06-10', '2024-06-14', 2, 1280, 'Pending', '2024-03-05', 'Pending'),
        ('David Chen', 'david.chen@email.com', 'Floating Villa Maldives', 'Baa Atoll, Maldives', '2024-07-01', '2024-07-05', 2, 2720, 'Confirmed', '2024-03-12', 'Paid');
      `;

      const result = await executeSQLCommand(insertDataSQL);
      
      if (!result.success) {
        console.error('Error inserting sample data:', result.error);
        return false;
      }

      console.log('Sample data inserted successfully');
      return true;
    } catch (error) {
      console.error('Error in insertSampleData:', error);
      return false;
    }
  };

  // NEW: Add 20 more diverse properties
  const addMoreProperties = async () => {
    setAddingMore(true);
    setError(null);
    setSuccess(null);
    
    try {
      console.log('Adding 20 more properties...');

      const addPropertiesSQL = `
        -- Insert 20 additional unique properties with proper array syntax
        INSERT INTO properties_j293sk4l59 (
          name, location, category, property_type, destination, location_type,
          price, description, image, images, features, accessibility,
          rating, guests, bedrooms, bathrooms, pet_friendly, instant_book,
          is_featured, ai_recommended, recommendation_reason
        ) VALUES
        (
          'Arctic Glass Igloo Experience',
          'Lapland, Finland',
          'Igloo',
          'Igloo',
          'Europe',
          'In the Arctic',
          380,
          'Sleep under the Northern Lights in this heated glass igloo with panoramic views of the Arctic wilderness.',
          'https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
          ARRAY['https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
          ARRAY['WiFi', 'Heated Floor', 'Northern Lights View', 'Stargazing', 'Hot Chocolate Service'],
          ARRAY[]::TEXT[],
          4.9,
          2,
          1,
          1,
          false,
          true,
          true,
          true,
          'Perfect for Northern Lights viewing'
        ),
        (
          'Santorini Cliff Cave House',
          'Oia, Santorini, Greece',
          'Cave',
          'Cave',
          'Europe',
          'In the mountains',
          420,
          'Traditional Cycladic cave house carved into the cliffs with stunning sunset views over the Aegean Sea.',
          'https://images.unsplash.com/photo-1613395877344-13d4a8e0d49e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
          ARRAY['https://images.unsplash.com/photo-1613395877344-13d4a8e0d49e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
          ARRAY['WiFi', 'Ocean Views', 'Sunset Views', 'Traditional Architecture', 'Private Terrace'],
          ARRAY[]::TEXT[],
          4.8,
          4,
          2,
          1,
          false,
          true,
          true,
          false,
          null
        ),
        (
          'Mount Fuji Ryokan Retreat',
          'Mount Fuji, Japan',
          'Wellness Retreat',
          'Ryokan',
          'Asia',
          'In the mountains',
          350,
          'Traditional Japanese inn with tatami rooms, hot springs, and views of Mount Fuji.',
          'https://images.unsplash.com/photo-1545569341-9eb8b30979d9?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
          ARRAY['https://images.unsplash.com/photo-1545569341-9eb8b30979d9?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
          ARRAY['WiFi', 'Hot Springs', 'Traditional Meals', 'Mountain Views', 'Meditation Space'],
          ARRAY[]::TEXT[],
          4.9,
          6,
          3,
          2,
          false,
          false,
          true,
          true,
          'Authentic Japanese cultural experience'
        ),
        (
          'Patagonian Wind Dome',
          'Torres del Paine, Chile',
          'Dome',
          'Dome',
          'South America',
          'In the wilderness',
          280,
          'Sustainable geodesic dome in the heart of Patagonia with panoramic mountain views.',
          'https://images.unsplash.com/photo-1464822759844-d150baec7c56?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
          ARRAY['https://images.unsplash.com/photo-1464822759844-d150baec7c56?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
          ARRAY['WiFi', 'Solar Power', 'Eco-Friendly', 'Mountain Views', 'Hiking Access'],
          ARRAY[]::TEXT[],
          4.7,
          4,
          2,
          1,
          true,
          true,
          false,
          true,
          'Perfect for adventure seekers'
        ),
        (
          'Tuscan Heritage Windmill',
          'Chianti, Italy',
          'Windmill',
          'Windmill',
          'Europe',
          'In the countryside',
          395,
          'Restored 18th-century windmill surrounded by vineyards in the heart of Tuscany.',
          'https://images.unsplash.com/photo-1523906834658-6e24ef2386f9?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
          ARRAY['https://images.unsplash.com/photo-1523906834658-6e24ef2386f9?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
          ARRAY['WiFi', 'Wine Tasting', 'Historic', 'Garden', 'Cooking Classes'],
          ARRAY[]::TEXT[],
          4.8,
          6,
          3,
          2,
          true,
          false,
          true,
          false,
          null
        ),
        (
          'Uluru Container Retreat',
          'Uluru, Australia',
          'Container Home',
          'Container',
          'Oceania',
          'In the desert',
          220,
          'Modern shipping container home with views of Uluru and the endless Australian outback.',
          'https://images.unsplash.com/photo-1449824913935-59a10b8d2000?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
          ARRAY['https://images.unsplash.com/photo-1449824913935-59a10b8d2000?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
          ARRAY['WiFi', 'Solar Power', 'Desert Views', 'Stargazing', 'Modern Design'],
          ARRAY[]::TEXT[],
          4.6,
          2,
          1,
          1,
          false,
          true,
          false,
          true,
          'Unique desert experience'
        ),
        (
          'Acadia Lighthouse Keeper House',
          'Acadia National Park, Maine, USA',
          'Lighthouse',
          'Lighthouse',
          'North America',
          'By the ocean',
          340,
          'Historic lighthouse keeper house on a rocky cliff overlooking the Atlantic Ocean.',
          'https://images.unsplash.com/photo-1518509562904-e7ef99cdcc86?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
          ARRAY['https://images.unsplash.com/photo-1518509562904-e7ef99cdcc86?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
          ARRAY['WiFi', 'Ocean Views', 'Historic', 'Lighthouse Tour', 'Beach Access'],
          ARRAY[]::TEXT[],
          4.7,
          4,
          2,
          1,
          true,
          true,
          true,
          false,
          null
        ),
        (
          'Kerala Traditional Houseboat',
          'Alleppey Backwaters, India',
          'Houseboat',
          'Houseboat',
          'Asia',
          'By the water',
          180,
          'Traditional Kerala houseboat cruising through serene backwaters and rice paddies.',
          'https://images.unsplash.com/photo-1544551763-46a013bb70d5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
          ARRAY['https://images.unsplash.com/photo-1544551763-46a013bb70d5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
          ARRAY['WiFi', 'Traditional Meals', 'Cultural Experience', 'Scenic Cruise', 'Local Guide'],
          ARRAY[]::TEXT[],
          4.8,
          6,
          3,
          2,
          false,
          true,
          false,
          true,
          'Authentic Indian cultural experience'
        ),
        (
          'Cotswolds Heritage Barn',
          'Cotswolds, England',
          'Barn',
          'Barn',
          'Europe',
          'In the countryside',
          290,
          'Beautifully converted 17th-century barn in the picturesque English countryside.',
          'https://images.unsplash.com/photo-1449824913935-59a10b8d2000?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
          ARRAY['https://images.unsplash.com/photo-1449824913935-59a10b8d2000?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
          ARRAY['WiFi', 'Fireplace', 'Garden', 'Historic', 'Countryside Views'],
          ARRAY['Wheelchair Access', 'Accessible Bathroom']::TEXT[],
          4.6,
          8,
          4,
          3,
          true,
          false,
          false,
          false,
          null
        ),
        (
          'Ubud Jungle Sanctuary Villa',
          'Ubud, Indonesia',
          'Villa',
          'Villa',
          'Asia',
          'In the jungle',
          250,
          'Luxury villa nestled in the Balinese jungle with infinity pool and rice terrace views.',
          'https://images.unsplash.com/photo-1470165311815-34e78ff7a111?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
          ARRAY['https://images.unsplash.com/photo-1470165311815-34e78ff7a111?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
          ARRAY['WiFi', 'Pool', 'Spa', 'Yoga Space', 'Jungle Views'],
          ARRAY[]::TEXT[],
          4.9,
          4,
          2,
          2,
          false,
          true,
          true,
          true,
          'Perfect for wellness and relaxation'
        ),
        (
          'Canadian Rockies Mountain Lodge',
          'Banff, Canada',
          'Lodge',
          'Lodge',
          'North America',
          'In the mountains',
          380,
          'Rustic mountain lodge with stunning views of the Canadian Rockies and wildlife viewing.',
          'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
          ARRAY['https://images.unsplash.com/photo-1441974231531-c6227db76b6e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
          ARRAY['WiFi', 'Fireplace', 'Mountain Views', 'Wildlife Viewing', 'Hiking'],
          ARRAY[]::TEXT[],
          4.8,
          10,
          5,
          3,
          true,
          false,
          true,
          false,
          null
        ),
        (
          'Maldives Exclusive Beach Resort',
          'Malé Atoll, Maldives',
          'Resort',
          'Resort',
          'Asia',
          'By the beach',
          750,
          'Exclusive beach resort with private beach access and world-class diving.',
          'https://images.unsplash.com/photo-1559827260-dc66d52bef19?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
          ARRAY['https://images.unsplash.com/photo-1559827260-dc66d52bef19?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
          ARRAY['WiFi', 'Beach Access', 'Spa', 'Restaurant', 'Snorkeling'],
          ARRAY[]::TEXT[],
          5.0,
          2,
          1,
          1,
          false,
          true,
          true,
          true,
          'Ultimate luxury beach experience'
        ),
        (
          'Vermont Organic Farm Stay',
          'Vermont, USA',
          'Farm Stay',
          'Farm',
          'North America',
          'In the countryside',
          160,
          'Working organic farm offering farm-to-table dining and hands-on agricultural experiences.',
          'https://images.unsplash.com/photo-1500382017468-9049fed747ef?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
          ARRAY['https://images.unsplash.com/photo-1500382017468-9049fed747ef?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
          ARRAY['WiFi', 'Farm Animals', 'Organic Food', 'Farm Tours', 'Eco-Friendly'],
          ARRAY[]::TEXT[],
          4.7,
          6,
          3,
          2,
          true,
          true,
          false,
          true,
          'Perfect for families and nature lovers'
        ),
        (
          'Marrakech Traditional Riad',
          'Marrakech, Morocco',
          'Villa',
          'Riad',
          'Africa',
          'In a city',
          200,
          'Traditional Moroccan riad in the heart of Marrakech medina with rooftop terrace.',
          'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
          ARRAY['https://images.unsplash.com/photo-1555041469-a586c61ea9bc?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
          ARRAY['WiFi', 'Traditional Architecture', 'Rooftop Terrace', 'Cultural Experience', 'City Views'],
          ARRAY[]::TEXT[],
          4.6,
          8,
          4,
          3,
          false,
          false,
          false,
          true,
          'Authentic Moroccan cultural experience'
        ),
        (
          'Geiranger Fjord Cabin',
          'Geiranger, Norway',
          'Forest Cabin',
          'Cabin',
          'Europe',
          'By the water',
          320,
          'Cozy cabin overlooking the dramatic Geiranger fjord with waterfall views.',
          'https://images.unsplash.com/photo-1464146072230-91cabc968266?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
          ARRAY['https://images.unsplash.com/photo-1464146072230-91cabc968266?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
          ARRAY['WiFi', 'Fjord Views', 'Hiking', 'Northern Lights', 'Fireplace'],
          ARRAY[]::TEXT[],
          4.9,
          4,
          2,
          1,
          false,
          true,
          true,
          true,
          'Spectacular fjord and waterfall views'
        ),
        (
          'Sahara Luxury Desert Camp',
          'Erg Chebbi, Morocco',
          'Dome',
          'Desert Camp',
          'Africa',
          'In the desert',
          190,
          'Luxury desert camp with traditional Berber tents under the Sahara stars.',
          'https://images.unsplash.com/photo-1561053362-2d9dd9f1f6e4?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
          ARRAY['https://images.unsplash.com/photo-1561053362-2d9dd9f1f6e4?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
          ARRAY['WiFi', 'Stargazing', 'Camel Trekking', 'Traditional Music', 'Desert Views'],
          ARRAY[]::TEXT[],
          4.8,
          2,
          1,
          1,
          false,
          true,
          false,
          true,
          'Ultimate desert adventure experience'
        ),
        (
          'Zermatt Alpine Chalet',
          'Zermatt, Switzerland',
          'Forest Cabin',
          'Chalet',
          'Europe',
          'In the mountains',
          480,
          'Traditional Swiss chalet with Matterhorn views and access to world-class skiing.',
          'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
          ARRAY['https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
          ARRAY['WiFi', 'Mountain Views', 'Skiing', 'Fireplace', 'Sauna'],
          ARRAY[]::TEXT[],
          4.9,
          8,
          4,
          3,
          false,
          false,
          true,
          false,
          null
        ),
        (
          'Blue Lagoon Geothermal Spa',
          'Blue Lagoon, Iceland',
          'Wellness Retreat',
          'Spa Resort',
          'Europe',
          'In the wilderness',
          520,
          'Luxury spa resort built around natural geothermal springs with Northern Lights viewing.',
          'https://images.unsplash.com/photo-1539650116574-75c0c6d73f6e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
          ARRAY['https://images.unsplash.com/photo-1539650116574-75c0c6d73f6e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
          ARRAY['WiFi', 'Geothermal Spa', 'Northern Lights', 'Wellness', 'Restaurant'],
          ARRAY['Wheelchair Access', 'Accessible Bathroom']::TEXT[],
          4.9,
          2,
          1,
          1,
          false,
          true,
          true,
          true,
          'Ultimate wellness and relaxation'
        ),
        (
          'Amazon Rainforest Eco Lodge',
          'Manaus, Brazil',
          'Lodge',
          'Eco Lodge',
          'South America',
          'In the jungle',
          240,
          'Eco-lodge deep in the Amazon rainforest with wildlife tours and canopy walks.',
          'https://images.unsplash.com/photo-1596306499317-8490e6e45deb?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
          ARRAY['https://images.unsplash.com/photo-1596306499317-8490e6e45deb?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
          ARRAY['WiFi', 'Wildlife Viewing', 'Eco-Friendly', 'Jungle Tours', 'Canopy Walk'],
          ARRAY[]::TEXT[],
          4.7,
          4,
          2,
          1,
          false,
          true,
          false,
          true,
          'Ultimate jungle adventure experience'
        ),
        (
          'Matamata Hobbit House',
          'Matamata, New Zealand',
          'Cave',
          'Hobbit House',
          'Oceania',
          'In the countryside',
          210,
          'Authentic hobbit house replica in the rolling hills of New Zealand with garden views.',
          'https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
          ARRAY['https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'],
          ARRAY['WiFi', 'Garden', 'Movie Set Tour', 'Countryside Views', 'Unique Architecture'],
          ARRAY[]::TEXT[],
          4.8,
          4,
          2,
          1,
          true,
          true,
          true,
          true,
          'Perfect for movie fans and families'
        );
      `;

      const result = await executeSQLCommand(addPropertiesSQL);
      
      if (!result.success) {
        setError(`Failed to add more properties: ${result.error.message}`);
        return;
      }
      
      setSuccess('Successfully added 20 more unique properties to the database!');
      
      // Refresh stats
      fetchDatabaseStats();
    } catch (error) {
      console.error('Error adding more properties:', error);
      setError('Failed to add more properties: ' + error.message);
    } finally {
      setAddingMore(false);
      setShowConfirmation(false);
    }
  };

  // Delete all data from the database
  const deleteAllData = async () => {
    setDeleting(true);
    setError(null);
    setSuccess(null);
    
    try {
      console.log('Deleting all data...');

      const deleteDataSQL = `
        -- Delete all data from tables in correct order (foreign key dependencies)
        DELETE FROM bookings_j293sk4l59;
        DELETE FROM properties_j293sk4l59;
        DELETE FROM users_j293sk4l59;
        DELETE FROM categories_j293sk4l59;
      `;

      const result = await executeSQLCommand(deleteDataSQL);
      
      if (!result.success) {
        setError(`Failed to delete data: ${result.error.message}`);
        return;
      }
      
      setSuccess('Successfully deleted all data from the database');
      fetchDatabaseStats(); // Refresh stats
    } catch (error) {
      console.error('Error deleting data:', error);
      setError('Failed to delete data: ' + error.message);
    } finally {
      setDeleting(false);
      setShowConfirmation(false);
    }
  };

  // Import comprehensive dataset
  const importComprehensiveDataset = async () => {
    setImporting(true);
    setError(null);
    setSuccess(null);
    
    try {
      console.log('Starting comprehensive dataset import...');
      
      // Step 1: Create tables
      const tablesCreated = await createTables();
      if (!tablesCreated) {
        setError('Failed to create database tables');
        return;
      }
      
      // Step 2: Insert sample data
      const dataInserted = await insertSampleData();
      if (!dataInserted) {
        setError('Failed to insert sample data');
        return;
      }

      setSuccess('Successfully imported comprehensive dataset with properties, categories, users, and bookings.');
      
      // Refresh stats
      fetchDatabaseStats();
    } catch (error) {
      console.error('Error importing dataset:', error);
      setError('Failed to import dataset: ' + error.message);
    } finally {
      setImporting(false);
      setShowConfirmation(false);
    }
  };

  // Show confirmation dialog before executing operations
  const confirmOperation = (op) => {
    setOperation(op);
    setShowConfirmation(true);
  };

  // Execute the confirmed operation
  const executeOperation = () => {
    if (operation === 'import') {
      importComprehensiveDataset();
    } else if (operation === 'delete') {
      deleteAllData();
    } else if (operation === 'add-more') {
      addMoreProperties();
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h3 className="text-xl font-semibold text-gray-900 mb-6 flex items-center">
        <SafeIcon icon={FiDatabase} className="h-6 w-6 text-primary-600 mr-2" />
        Database Management
      </h3>

      {/* Connection Status */}
      <div className={`mb-6 p-4 rounded-lg ${
        connectionStatus === 'connected' ? 'bg-green-50 text-green-700 border border-green-200' :
        connectionStatus === 'error' ? 'bg-red-50 text-red-700 border border-red-200' :
        'bg-yellow-50 text-yellow-700 border border-yellow-200'
      }`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            {connectionStatus === 'connected' ? (
              <SafeIcon icon={FiCheckCircle} className="h-5 w-5 mr-2" />
            ) : connectionStatus === 'error' ? (
              <SafeIcon icon={FiAlertCircle} className="h-5 w-5 mr-2" />
            ) : (
              <SafeIcon icon={FiLoader} className="h-5 w-5 mr-2 animate-spin" />
            )}
            <span>
              Database Status: {
                connectionStatus === 'connected' ? 'Connected' :
                connectionStatus === 'error' ? 'Connection Error' :
                'Checking...'
              }
            </span>
          </div>
          <button 
            onClick={checkConnection} 
            className="text-sm flex items-center"
            disabled={connectionStatus === 'checking'}
          >
            <SafeIcon 
              icon={FiRefreshCw} 
              className={`h-4 w-4 mr-1 ${connectionStatus === 'checking' ? 'animate-spin' : ''}`} 
            />
            {connectionStatus === 'checking' ? 'Checking...' : 'Check Connection'}
          </button>
        </div>
      </div>

      {/* Database Stats */}
      <div className="mb-6 p-4 bg-gray-50 rounded-lg">
        <div className="flex justify-between items-center mb-4">
          <h4 className="font-medium text-gray-900">Current Database Statistics</h4>
          <button 
            onClick={fetchDatabaseStats} 
            disabled={loadingStats || connectionStatus !== 'connected'}
            className={`text-primary-600 hover:text-primary-700 flex items-center text-sm ${(loadingStats || connectionStatus !== 'connected') ? 'opacity-50 cursor-not-allowed' : ''}`}
          >
            <SafeIcon icon={FiRefreshCw} className={`h-4 w-4 mr-1 ${loadingStats ? 'animate-spin' : ''}`} />
            Refresh
          </button>
        </div>
        
        {loadingStats ? (
          <div className="animate-pulse space-y-2">
            <div className="h-4 bg-gray-200 rounded w-1/4"></div>
            <div className="h-4 bg-gray-200 rounded w-1/3"></div>
            <div className="h-4 bg-gray-200 rounded w-1/2"></div>
          </div>
        ) : stats ? (
          <div className="grid grid-cols-2 gap-4">
            <div className="flex justify-between p-2 bg-white rounded border border-gray-100">
              <span className="text-gray-600">Properties:</span>
              <span className="font-medium">{stats.properties_j293sk4l59 || 0}</span>
            </div>
            <div className="flex justify-between p-2 bg-white rounded border border-gray-100">
              <span className="text-gray-600">Categories:</span>
              <span className="font-medium">{stats.categories_j293sk4l59 || 0}</span>
            </div>
            <div className="flex justify-between p-2 bg-white rounded border border-gray-100">
              <span className="text-gray-600">Users:</span>
              <span className="font-medium">{stats.users_j293sk4l59 || 0}</span>
            </div>
            <div className="flex justify-between p-2 bg-white rounded border border-gray-100">
              <span className="text-gray-600">Bookings:</span>
              <span className="font-medium">{stats.bookings_j293sk4l59 || 0}</span>
            </div>
          </div>
        ) : (
          <p className="text-gray-500">No database statistics available</p>
        )}
      </div>

      {/* Actions */}
      <div className="space-y-4">
        <div className="p-4 border border-gray-200 rounded-lg">
          <h4 className="font-medium text-gray-900 mb-3">Import Comprehensive Dataset</h4>
          <p className="text-gray-600 mb-4">
            Import a complete set of properties, categories, users, and bookings with realistic data.
            <br/>
            <span className="text-sm font-medium text-red-600">
              Note: This will recreate all tables and import fresh sample data.
            </span>
          </p>
          <button
            onClick={() => confirmOperation('import')}
            disabled={importing || connectionStatus !== 'connected'}
            className="bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded-lg flex items-center disabled:bg-primary-400"
          >
            {importing ? (
              <>
                <SafeIcon icon={FiLoader} className="h-5 w-5 mr-2 animate-spin" />
                Importing...
              </>
            ) : (
              <>
                <SafeIcon icon={FiUpload} className="h-5 w-5 mr-2" />
                Import Dataset
              </>
            )}
          </button>
        </div>

        {/* NEW: Add More Properties Button */}
        <div className="p-4 border border-green-200 bg-green-50 rounded-lg">
          <h4 className="font-medium text-gray-900 mb-3">Add More Properties</h4>
          <p className="text-gray-600 mb-4">
            Add 20 more diverse and unique properties to your existing database.
            <br/>
            <span className="text-sm font-medium text-green-600">
              This will add properties without affecting existing data.
            </span>
          </p>
          <button
            onClick={() => confirmOperation('add-more')}
            disabled={addingMore || connectionStatus !== 'connected'}
            className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg flex items-center disabled:bg-green-400"
          >
            {addingMore ? (
              <>
                <SafeIcon icon={FiLoader} className="h-5 w-5 mr-2 animate-spin" />
                Adding Properties...
              </>
            ) : (
              <>
                <SafeIcon icon={FiPlusCircle} className="h-5 w-5 mr-2" />
                Add 20 More Properties
              </>
            )}
          </button>
        </div>

        <div className="p-4 border border-gray-200 rounded-lg">
          <h4 className="font-medium text-gray-900 mb-3">Delete All Data</h4>
          <p className="text-gray-600 mb-4">
            Remove all data from all tables. This action cannot be undone.
            The tables structure will remain intact.
          </p>
          <button
            onClick={() => confirmOperation('delete')}
            disabled={deleting || connectionStatus !== 'connected'}
            className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg flex items-center disabled:bg-red-400"
          >
            {deleting ? (
              <>
                <SafeIcon icon={FiLoader} className="h-5 w-5 mr-2 animate-spin" />
                Deleting...
              </>
            ) : (
              <>
                <SafeIcon icon={FiTrash2} className="h-5 w-5 mr-2" />
                Delete All Data
              </>
            )}
          </button>
        </div>
      </div>

      {/* Success/Error Messages */}
      {error && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-6 p-4 bg-red-50 border border-red-200 text-red-700 rounded-lg flex items-start"
        >
          <SafeIcon icon={FiAlertCircle} className="h-5 w-5 mr-2 mt-0.5" />
          <div className="flex-1">{error}</div>
          <button onClick={() => setError(null)} className="text-red-500 hover:text-red-700">
            <SafeIcon icon={FiX} className="h-5 w-5" />
          </button>
        </motion.div>
      )}

      {success && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-6 p-4 bg-green-50 border border-green-200 text-green-700 rounded-lg flex items-start"
        >
          <SafeIcon icon={FiCheckCircle} className="h-5 w-5 mr-2 mt-0.5" />
          <div className="flex-1">{success}</div>
          <button onClick={() => setSuccess(null)} className="text-green-500 hover:text-green-700">
            <SafeIcon icon={FiX} className="h-5 w-5" />
          </button>
        </motion.div>
      )}

      {/* Confirmation Modal */}
      {showConfirmation && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.3 }}
            className="bg-white rounded-lg p-6 max-w-md w-full mx-4"
          >
            <h3 className="text-xl font-semibold text-gray-900 mb-4">
              Confirm {operation === 'import' ? 'Import' : operation === 'add-more' ? 'Add Properties' : 'Deletion'}
            </h3>
            <div className="bg-yellow-50 border border-yellow-100 p-4 rounded-lg mb-6">
              <div className="flex">
                <SafeIcon icon={FiAlertCircle} className="h-5 w-5 text-yellow-600 mr-2 mt-0.5" />
                <div>
                  {operation === 'import' ? (
                    <p className="text-yellow-700">
                      This will <strong>recreate all tables</strong> and import fresh sample data. Any existing data will be permanently lost.
                    </p>
                  ) : operation === 'add-more' ? (
                    <p className="text-yellow-700">
                      This will add 20 more unique properties to your existing database. This action cannot be undone.
                    </p>
                  ) : (
                    <p className="text-yellow-700">
                      This will permanently delete ALL data from ALL tables. This action cannot be undone.
                    </p>
                  )}
                </div>
              </div>
            </div>
            <div className="flex justify-end space-x-3">
              <button
                onClick={() => setShowConfirmation(false)}
                className="px-4 py-2 bg-gray-100 text-gray-800 rounded-lg hover:bg-gray-200 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={executeOperation}
                className={`px-4 py-2 rounded-lg text-white transition-colors ${
                  operation === 'import'
                    ? 'bg-primary-600 hover:bg-primary-700'
                    : operation === 'add-more'
                    ? 'bg-green-600 hover:bg-green-700'
                    : 'bg-red-600 hover:bg-red-700'
                }`}
              >
                {operation === 'import' ? 'Confirm Import' : operation === 'add-more' ? 'Add Properties' : 'Confirm Delete'}
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
};

export default DatabaseImport;