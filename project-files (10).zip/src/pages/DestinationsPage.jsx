import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link, useSearchParams } from 'react-router-dom';
import * as FiIcons from 'react-icons/fi';
import SafeIcon from '../common/SafeIcon';
import MapView from '../components/MapView';
import { useFavorites } from '../contexts/FavoritesContext';
import supabase from '../lib/supabase';

const { FiFilter, FiStar, FiMapPin, FiSearch, FiDollarSign, FiHome, FiMap, FiList, FiX, FiChevronDown, FiSliders, FiGlobe, FiZap, FiWind, FiCheck, FiFlag, FiDroplet, FiSun, FiHeart, FiCoffee, FiShield, FiPlusCircle, FiMinusCircle, FiUsers, FiZoomIn, FiWifi } = FiIcons;

const DestinationsPage = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDestination, setSelectedDestination] = useState('All');
  const [selectedPropertyType, setSelectedPropertyType] = useState('All');
  const [selectedLocationTypes, setSelectedLocationTypes] = useState([]);
  const [selectedFeatures, setSelectedFeatures] = useState([]);
  const [selectedAccessibility, setSelectedAccessibility] = useState([]);
  const [priceRange, setPriceRange] = useState([0, 1000]);
  const [minRating, setMinRating] = useState(0);
  const [guestCount, setGuestCount] = useState(1);
  const [petFriendly, setPetFriendly] = useState(false);
  const [instantBook, setInstantBook] = useState(false);
  const [filtersVisible, setFiltersVisible] = useState(false);
  const [activeFilters, setActiveFilters] = useState(0);
  const [viewMode, setViewMode] = useState('list'); // 'list' or 'map'
  const [mapCenter, setMapCenter] = useState([20, 0]); // Default center of the world
  const [mapZoom, setMapZoom] = useState(2); // Default zoom level
  const [activeStay, setActiveStay] = useState(null); // For map popups
  const [mapLoaded, setMapLoaded] = useState(false);
  const [allStays, setAllStays] = useState([]);
  const [loading, setLoading] = useState(true);

  const { addFavorite, removeFavorite, isFavorite } = useFavorites();

  // Filter options
  const destinations = ['All', 'Europe', 'North America', 'Asia', 'Africa', 'Oceania', 'South America'];
  const propertyTypes = ['All', 'Treehouse', 'Castle', 'Modern', 'Overwater', 'Cave', 'Igloo', 'Forest Cabin', 'Wellness Retreat', 'Lighthouse', 'Houseboat', 'Dome', 'Container Home', 'Windmill', 'Barn', 'Villa', 'Lodge', 'Resort', 'Farm Stay'];
  const locationTypes = ['In a forest', 'By the water', 'In a city', 'In the mountains', 'By the beach', 'In the countryside', 'In the desert', 'In the wilderness', 'In the jungle', 'By the ocean', 'Over water', 'Underground', 'In the Arctic', 'In the savanna'];
  const features = ['WiFi', 'Kitchen', 'Pool', 'Hot Tub', 'Sauna', 'Fireplace', 'Garden', 'Pet Friendly', 'Spa', 'Restaurant', 'Beach Access', 'Ocean Views', 'City Views', 'Mountain Views', 'Wildlife Viewing', 'Stargazing', 'Historic', 'Eco-Friendly', 'Solar Power', 'Wine Tasting', 'Yoga Space', 'Art Studio', 'Farm Animals', 'Northern Lights', 'Snorkeling', 'Hiking'];
  const accessibilityOptions = ['Wheelchair Access', 'Elevator', 'Accessible Bathroom', 'Roll-in Shower', 'Grab Bars', 'Wide Doorways', 'Ramp Access', 'Accessible Parking'];

  // Get category from URL parameters
  useEffect(() => {
    const categoryParam = searchParams.get('category');
    if (categoryParam) {
      setSelectedPropertyType(categoryParam);
      setFiltersVisible(true);
    }
  }, [searchParams]);

  // Fetch properties from Supabase when component mounts
  useEffect(() => {
    const fetchProperties = async () => {
      try {
        setLoading(true);
        console.log('Fetching properties from Supabase...');
        
        const { data, error } = await supabase
          .from('properties_j293sk4l59')
          .select('*')
          .eq('status', 'Active')
          .order('created_at', { ascending: false });

        if (error) {
          console.error('Error fetching properties:', error);
          // Fall back to sample data if there's an error
          setAllStays(sampleStays);
        } else {
          console.log('Properties fetched successfully:', data);
          if (data && data.length > 0) {
            // Transform the data to match the expected format
            const formattedStays = data.map(property => ({
              id: property.id,
              name: property.name,
              location: property.location,
              image: property.image || 'https://images.unsplash.com/photo-1571896349842-33c89424de2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
              rating: property.rating || 4.5,
              price: property.price?.toString() || '0',
              priceValue: parseFloat(property.price) || 0,
              category: property.category || 'Modern',
              destination: property.destination || 'Europe',
              propertyType: property.property_type || property.category || 'Modern',
              locationType: property.location_type || 'In the countryside',
              features: Array.isArray(property.features) ? property.features : (property.features ? [property.features] : ['WiFi']),
              accessibility: Array.isArray(property.accessibility) ? property.accessibility : (property.accessibility ? [property.accessibility] : []),
              guests: property.guests || 2,
              bedrooms: property.bedrooms || 1,
              bathrooms: property.bathrooms || 1,
              petFriendly: property.pet_friendly || false,
              instantBook: property.instant_book || false,
              coordinates: property.coordinates || [Math.random() * 180 - 90, Math.random() * 360 - 180] // Random coordinates if none provided
            }));
            
            setAllStays(formattedStays);
          } else {
            // Fall back to sample data if no data returned
            setAllStays(sampleStays);
          }
        }
      } catch (error) {
        console.error('Failed to fetch properties:', error);
        setAllStays(sampleStays);
      } finally {
        setLoading(false);
      }
    };

    fetchProperties();
  }, []);

  // Sample stays data with comprehensive filters (fallback data)
  const sampleStays = [
    {
      id: 1,
      name: "Treehouse Paradise",
      location: "Costa Rica",
      image: "https://images.unsplash.com/photo-1571896349842-33c89424de2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      rating: 4.9,
      price: "180",
      priceValue: 180,
      category: "Treehouse",
      destination: "North America",
      propertyType: "Treehouse",
      locationType: "In a forest",
      features: ["WiFi", "Kitchen", "Outdoor Shower", "Wildlife Viewing"],
      accessibility: [],
      guests: 2,
      bedrooms: 1,
      bathrooms: 1,
      petFriendly: false,
      instantBook: true,
      coordinates: [9.9281, -84.0907]
    },
    {
      id: 2,
      name: "Castle in the Clouds",
      location: "Scotland",
      image: "https://images.unsplash.com/photo-1520637836862-4d197d17c92a?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      rating: 4.8,
      price: "450",
      priceValue: 450,
      category: "Castle",
      destination: "Europe",
      propertyType: "Castle",
      locationType: "In the mountains",
      features: ["WiFi", "Fireplace", "Kitchen", "Historic", "Garden"],
      accessibility: [],
      guests: 8,
      bedrooms: 4,
      bathrooms: 3,
      petFriendly: false,
      instantBook: false,
      coordinates: [56.4907, -4.2026]
    },
    {
      id: 3,
      name: "Lakeside Forest Cabin",
      location: "Black Forest, Germany",
      image: "https://images.unsplash.com/photo-1464146072230-91cabc968266?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      rating: 4.8,
      price: "220",
      priceValue: 220,
      category: "Forest Cabin",
      destination: "Europe",
      propertyType: "Cabin",
      locationType: "By the water",
      features: ["WiFi", "Hot Tub", "Fireplace", "Kitchen", "Pet Friendly"],
      accessibility: [],
      guests: 4,
      bedrooms: 2,
      bathrooms: 1,
      petFriendly: true,
      instantBook: true,
      coordinates: [48.3, 8.2]
    },
    {
      id: 4,
      name: "Amsterdam Houseboat",
      location: "Amsterdam, Netherlands",
      image: "https://images.unsplash.com/photo-1544551763-46a013bb70d5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      rating: 4.6,
      price: "180",
      priceValue: 180,
      category: "Houseboat",
      destination: "Europe",
      propertyType: "Boat",
      locationType: "By the water",
      features: ["WiFi", "Kitchen", "Waterfront"],
      accessibility: [],
      guests: 2,
      bedrooms: 1,
      bathrooms: 1,
      petFriendly: false,
      instantBook: true,
      coordinates: [52.3676, 4.9041]
    },
    {
      id: 5,
      name: "Tuscany Wellness Retreat",
      location: "Tuscany, Italy",
      image: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      rating: 4.9,
      price: "380",
      priceValue: 380,
      category: "Wellness Retreat",
      destination: "Europe",
      propertyType: "Villa",
      locationType: "In the countryside",
      features: ["WiFi", "Spa", "Sauna", "Hot Tub", "Pool", "Kitchen", "Garden"],
      accessibility: [],
      guests: 8,
      bedrooms: 4,
      bathrooms: 3,
      petFriendly: true,
      instantBook: false,
      coordinates: [43.7711, 11.2486]
    },
    {
      id: 6,
      name: "Toronto Urban Loft",
      location: "Toronto, Canada",
      image: "https://images.unsplash.com/photo-1582719508461-905c673771fd?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      rating: 4.5,
      price: "160",
      priceValue: 160,
      category: "Modern",
      destination: "North America",
      propertyType: "Apartment",
      locationType: "In a city",
      features: ["WiFi", "Kitchen", "City Views", "Elevator"],
      accessibility: ["Wheelchair Access", "Elevator"],
      guests: 4,
      bedrooms: 2,
      bathrooms: 2,
      petFriendly: true,
      instantBook: true,
      coordinates: [43.6532, -79.3832]
    },
    {
      id: 7,
      name: "Accessible Lakeside Resort",
      location: "Lake District, England",
      image: "https://images.unsplash.com/photo-1544551763-46a013bb70d5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      rating: 4.7,
      price: "280",
      priceValue: 280,
      category: "Resort",
      destination: "Europe",
      propertyType: "Resort",
      locationType: "By the water",
      features: ["WiFi", "Restaurant", "Spa", "Pool", "Garden"],
      accessibility: ["Wheelchair Access", "Elevator", "Accessible Bathroom", "Roll-in Shower"],
      guests: 6,
      bedrooms: 3,
      bathrooms: 2,
      petFriendly: true,
      instantBook: true,
      coordinates: [54.4609, -3.0886]
    },
    {
      id: 8,
      name: "Bali Bamboo Villa",
      location: "Ubud, Indonesia",
      image: "https://images.unsplash.com/photo-1470165311815-34e78ff7a111?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      rating: 4.6,
      price: "180",
      priceValue: 180,
      category: "Villa",
      destination: "Asia",
      propertyType: "Villa",
      locationType: "In the jungle",
      features: ["WiFi", "Pool", "Garden", "Yoga Space"],
      accessibility: [],
      guests: 4,
      bedrooms: 2,
      bathrooms: 2,
      petFriendly: false,
      instantBook: true,
      coordinates: [-8.5069, 115.2625]
    }
  ];

  // Calculate max price for range filter
  const maxPrice = Math.max(...allStays.map(stay => stay.priceValue), 1000);

  // Update active filters count
  useEffect(() => {
    let count = 0;
    if (selectedDestination !== 'All') count++;
    if (selectedPropertyType !== 'All') count++;
    if (selectedLocationTypes.length > 0) count++;
    if (selectedFeatures.length > 0) count++;
    if (selectedAccessibility.length > 0) count++;
    if (minRating > 0) count++;
    if (priceRange[0] > 0 || priceRange[1] < maxPrice) count++;
    if (guestCount > 1) count++;
    if (petFriendly) count++;
    if (instantBook) count++;
    setActiveFilters(count);
  }, [selectedDestination, selectedPropertyType, selectedLocationTypes, selectedFeatures, selectedAccessibility, minRating, priceRange, maxPrice, guestCount, petFriendly, instantBook]);

  // Update URL when category changes
  useEffect(() => {
    if (selectedPropertyType !== 'All') {
      searchParams.set('category', selectedPropertyType);
    } else {
      searchParams.delete('category');
    }
    setSearchParams(searchParams);
  }, [selectedPropertyType]);

  const filteredStays = allStays.filter(stay => {
    // Text search
    const matchesSearch = searchTerm === '' || 
      stay.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
      stay.location.toLowerCase().includes(searchTerm.toLowerCase()) || 
      stay.category.toLowerCase().includes(searchTerm.toLowerCase());

    // Destination filter
    const matchesDestination = selectedDestination === 'All' || stay.destination === selectedDestination;

    // Property type filter
    const matchesPropertyType = selectedPropertyType === 'All' || 
      stay.propertyType === selectedPropertyType || 
      stay.category === selectedPropertyType;

    // Location type filter
    const matchesLocationType = selectedLocationTypes.length === 0 || 
      selectedLocationTypes.includes(stay.locationType);

    // Features filter
    const matchesFeatures = selectedFeatures.length === 0 || 
      selectedFeatures.every(feature => stay.features.includes(feature));

    // Accessibility filter
    const matchesAccessibility = selectedAccessibility.length === 0 || 
      selectedAccessibility.every(accessibility => stay.accessibility.includes(accessibility));

    // Price range filter
    const matchesPrice = stay.priceValue >= priceRange[0] && stay.priceValue <= priceRange[1];

    // Rating filter
    const matchesRating = stay.rating >= minRating;

    // Guest count filter
    const matchesGuests = stay.guests >= guestCount;

    // Pet friendly filter
    const matchesPetFriendly = !petFriendly || stay.petFriendly;

    // Instant book filter
    const matchesInstantBook = !instantBook || stay.instantBook;

    return matchesSearch && matchesDestination && matchesPropertyType && 
           matchesLocationType && matchesFeatures && matchesAccessibility && 
           matchesPrice && matchesRating && matchesGuests && 
           matchesPetFriendly && matchesInstantBook;
  });

  // Reset all filters
  const clearAllFilters = () => {
    setSelectedDestination('All');
    setSelectedPropertyType('All');
    setSelectedLocationTypes([]);
    setSelectedFeatures([]);
    setSelectedAccessibility([]);
    setPriceRange([0, maxPrice]);
    setMinRating(0);
    setGuestCount(1);
    setPetFriendly(false);
    setInstantBook(false);
    setSearchTerm('');
    // Reset map view
    setMapCenter([20, 0]);
    setMapZoom(2);
  };

  // Toggle selection helpers
  const toggleSelection = (item, selectedItems, setSelectedItems) => {
    if (selectedItems.includes(item)) {
      setSelectedItems(selectedItems.filter(i => i !== item));
    } else {
      setSelectedItems([...selectedItems, item]);
    }
  };

  // Handle map marker click
  const handleMarkerClick = (stay) => {
    setActiveStay(stay);
  };

  // Zoom to stay location
  const zoomToStay = (stay) => {
    if (stay.coordinates) {
      setMapCenter(stay.coordinates);
      setMapZoom(12); // Zoom in closely
      setViewMode('map'); // Switch to map view
    }
  };

  // Handle favorite toggle
  const handleFavoriteToggle = (e, stay) => {
    e.preventDefault();
    e.stopPropagation();
    if (isFavorite(stay.id)) {
      removeFavorite(stay.id);
    } else {
      addFavorite(stay);
    }
  };

  if (loading) {
    return (
      <div className="pt-16 min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-pulse space-y-6 w-full max-w-7xl px-4">
          <div className="h-12 bg-gray-200 rounded w-1/3"></div>
          <div className="h-10 bg-gray-200 rounded w-full"></div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="h-64 bg-gray-200 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
      className="pt-16 min-h-screen bg-gray-50"
    >
      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <motion.div
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-4xl md:text-5xl font-serif font-bold text-gray-900 mb-4">
              Unique Destinations
            </h1>
            <p className="text-xl text-gray-600 mb-8">
              Discover extraordinary places to stay around the world
            </p>

            {/* Search and Filter */}
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <SafeIcon
                  icon={FiSearch}
                  className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400"
                />
                <input
                  type="text"
                  placeholder="Search destinations, locations, or stay types..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                />
                {searchTerm && (
                  <button
                    onClick={() => setSearchTerm('')}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  >
                    <SafeIcon icon={FiX} className="h-5 w-5" />
                  </button>
                )}
              </div>
              <div className="flex gap-2">
                {/* View toggle buttons */}
                <div className="flex rounded-lg border border-gray-300 overflow-hidden">
                  <button
                    onClick={() => setViewMode('list')}
                    className={`flex items-center justify-center px-4 py-3 ${
                      viewMode === 'list'
                        ? 'bg-primary-600 text-white'
                        : 'bg-white text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    <SafeIcon icon={FiList} className="h-5 w-5" />
                    <span className="ml-2 hidden sm:inline">List</span>
                  </button>
                  <button
                    onClick={() => setViewMode('map')}
                    className={`flex items-center justify-center px-4 py-3 ${
                      viewMode === 'map'
                        ? 'bg-primary-600 text-white'
                        : 'bg-white text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    <SafeIcon icon={FiMap} className="h-5 w-5" />
                    <span className="ml-2 hidden sm:inline">Map</span>
                  </button>
                </div>
                <button
                  onClick={() => setFiltersVisible(!filtersVisible)}
                  className="flex items-center justify-center gap-2 px-4 py-3 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors"
                >
                  <SafeIcon icon={FiSliders} className="h-5 w-5" />
                  <span>Filters</span>
                  {activeFilters > 0 && (
                    <span className="bg-white text-primary-700 rounded-full h-6 w-6 flex items-center justify-center text-sm font-medium">
                      {activeFilters}
                    </span>
                  )}
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Enhanced Filters Panel */}
      {filtersVisible && (
        <motion.div
          initial={{ height: 0, opacity: 0 }}
          animate={{ height: 'auto', opacity: 1 }}
          exit={{ height: 0, opacity: 0 }}
          transition={{ duration: 0.3 }}
          className="bg-white border-b border-gray-200 overflow-hidden"
        >
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {/* Destination Filter */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Destination</label>
                <select
                  value={selectedDestination}
                  onChange={(e) => setSelectedDestination(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                >
                  {destinations.map(destination => (
                    <option key={destination} value={destination}>{destination}</option>
                  ))}
                </select>
              </div>

              {/* Property Type Filter */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Property Type</label>
                <select
                  value={selectedPropertyType}
                  onChange={(e) => setSelectedPropertyType(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                >
                  {propertyTypes.map(type => (
                    <option key={type} value={type}>{type}</option>
                  ))}
                </select>
              </div>

              {/* Price Range Filter */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Price Range: €{priceRange[0]} - €{priceRange[1]}
                </label>
                <div className="flex items-center space-x-2">
                  <input
                    type="range"
                    min="0"
                    max={maxPrice}
                    value={priceRange[0]}
                    onChange={(e) => setPriceRange([parseInt(e.target.value), priceRange[1]])}
                    className="flex-1"
                  />
                  <input
                    type="range"
                    min="0"
                    max={maxPrice}
                    value={priceRange[1]}
                    onChange={(e) => setPriceRange([priceRange[0], parseInt(e.target.value)])}
                    className="flex-1"
                  />
                </div>
              </div>

              {/* Guests Filter */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Guests: {guestCount}+
                </label>
                <input
                  type="range"
                  min="1"
                  max="12"
                  value={guestCount}
                  onChange={(e) => setGuestCount(parseInt(e.target.value))}
                  className="w-full"
                />
              </div>
            </div>

            {/* Second row of filters */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-6">
              {/* Location Type Filter */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Location</label>
                <div className="max-h-32 overflow-y-auto border border-gray-300 rounded-lg p-2">
                  {locationTypes.map(locationType => (
                    <label key={locationType} className="flex items-center space-x-2 text-sm">
                      <input
                        type="checkbox"
                        checked={selectedLocationTypes.includes(locationType)}
                        onChange={() => toggleSelection(locationType, selectedLocationTypes, setSelectedLocationTypes)}
                        className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                      />
                      <span>{locationType}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Features Filter */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Features</label>
                <div className="max-h-32 overflow-y-auto border border-gray-300 rounded-lg p-2">
                  {features.map(feature => (
                    <label key={feature} className="flex items-center space-x-2 text-sm">
                      <input
                        type="checkbox"
                        checked={selectedFeatures.includes(feature)}
                        onChange={() => toggleSelection(feature, selectedFeatures, setSelectedFeatures)}
                        className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                      />
                      <span>{feature}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Accessibility Filter */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Accessibility</label>
                <div className="max-h-32 overflow-y-auto border border-gray-300 rounded-lg p-2">
                  {accessibilityOptions.map(accessibility => (
                    <label key={accessibility} className="flex items-center space-x-2 text-sm">
                      <input
                        type="checkbox"
                        checked={selectedAccessibility.includes(accessibility)}
                        onChange={() => toggleSelection(accessibility, selectedAccessibility, setSelectedAccessibility)}
                        className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                      />
                      <span>{accessibility}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Additional Filters */}
              <div className="space-y-4">
                {/* Rating Filter */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Minimum Rating: {minRating > 0 ? minRating : 'Any'}
                  </label>
                  <input
                    type="range"
                    min="0"
                    max="5"
                    step="0.5"
                    value={minRating}
                    onChange={(e) => setMinRating(parseFloat(e.target.value))}
                    className="w-full"
                  />
                </div>

                {/* Toggle Filters */}
                <div className="space-y-2">
                  <label className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      checked={petFriendly}
                      onChange={(e) => setPetFriendly(e.target.checked)}
                      className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                    />
                    <span className="text-sm">Pet Friendly</span>
                  </label>
                  <label className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      checked={instantBook}
                      onChange={(e) => setInstantBook(e.target.checked)}
                      className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                    />
                    <span className="text-sm">Instant Book</span>
                  </label>
                </div>
              </div>
            </div>

            {/* Clear Filters */}
            {activeFilters > 0 && (
              <div className="mt-6 text-center">
                <button
                  onClick={clearAllFilters}
                  className="inline-flex items-center px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
                >
                  <SafeIcon icon={FiX} className="h-4 w-4 mr-2" />
                  Clear all filters ({activeFilters})
                </button>
              </div>
            )}
          </div>
        </motion.div>
      )}

      {/* Results */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Results count */}
        <div className="mb-6">
          <p className="text-gray-600">
            <span className="font-medium">{filteredStays.length}</span>{' '}
            {filteredStays.length === 1 ? 'stay' : 'stays'} found
            {activeFilters > 0 && ' matching your filters'}
          </p>
        </div>

        {/* View content - Map or List */}
        {viewMode === 'map' ? (
          <div
            className="bg-white rounded-2xl shadow-lg overflow-hidden"
            style={{ height: '70vh', minHeight: '600px' }}
          >
            <MapView
              stays={filteredStays}
              center={mapCenter}
              zoom={mapZoom}
              onMarkerClick={handleMarkerClick}
              activeStay={activeStay}
              setMapLoaded={setMapLoaded}
            />
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredStays.map((stay, index) => (
              <motion.div
                key={stay.id}
                initial={{ y: 50, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                whileHover={{ y: -10 }}
                className="bg-white rounded-2xl shadow-lg overflow-hidden group cursor-pointer relative"
              >
                <Link to={`/stay/${stay.id}`}>
                  <div className="relative overflow-hidden">
                    <img
                      src={stay.image}
                      alt={stay.name}
                      className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    <div className="absolute top-4 left-4 bg-primary-600 text-white px-3 py-1 rounded-full text-sm font-medium">
                      {stay.category}
                    </div>
                    {/* Location Type Tag */}
                    <div className="absolute top-4 right-16 bg-black bg-opacity-50 text-white px-3 py-1 rounded-full text-xs font-medium">
                      {stay.locationType}
                    </div>
                    {/* Pet Friendly Badge */}
                    {stay.petFriendly && (
                      <div className="absolute bottom-4 left-4 bg-green-500 text-white px-2 py-1 rounded-full text-xs font-medium">
                        Pet Friendly
                      </div>
                    )}
                    {/* Instant Book Badge */}
                    {stay.instantBook && (
                      <div className="absolute bottom-4 right-4 bg-blue-500 text-white px-2 py-1 rounded-full text-xs font-medium">
                        Instant Book
                      </div>
                    )}
                  </div>
                  <div className="p-6">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-xl font-semibold text-gray-900 group-hover:text-primary-600 transition-colors">
                        {stay.name}
                      </h3>
                      <div className="flex items-center space-x-1">
                        <SafeIcon icon={FiStar} className="h-4 w-4 text-yellow-400 fill-current" />
                        <span className="text-sm font-medium text-gray-700">{stay.rating}</span>
                      </div>
                    </div>
                    <div className="flex items-center space-x-1 mb-4">
                      <SafeIcon icon={FiMapPin} className="h-4 w-4 text-gray-400" />
                      <span className="text-gray-600">{stay.location}</span>
                    </div>
                    {/* Feature Tags */}
                    {stay.features && stay.features.length > 0 && (
                      <div className="flex flex-wrap gap-1 mb-3">
                        {stay.features.slice(0, 3).map((feature, idx) => (
                          <span key={idx} className="text-xs bg-gray-100 text-gray-700 px-2 py-1 rounded">
                            {feature}
                          </span>
                        ))}
                        {stay.features.length > 3 && (
                          <span className="text-xs bg-gray-100 text-gray-700 px-2 py-1 rounded">
                            +{stay.features.length - 3}
                          </span>
                        )}
                      </div>
                    )}
                    {/* Accessibility Features */}
                    {stay.accessibility && stay.accessibility.length > 0 && (
                      <div className="flex flex-wrap gap-1 mb-3">
                        {stay.accessibility.slice(0, 2).map((access, idx) => (
                          <span key={idx} className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded">
                            {access}
                          </span>
                        ))}
                        {stay.accessibility.length > 2 && (
                          <span className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded">
                            +{stay.accessibility.length - 2} accessible
                          </span>
                        )}
                      </div>
                    )}
                    <div className="flex items-center justify-between">
                      <span className="text-2xl font-bold text-primary-600">€{stay.price}</span>
                      <div className="flex items-center space-x-4">
                        <span className="text-gray-500">per night</span>
                        <span className="text-sm text-gray-600 flex items-center">
                          <SafeIcon icon={FiUsers} className="h-4 w-4 mr-1" />
                          {stay.guests}
                        </span>
                      </div>
                    </div>
                  </div>
                </Link>
                {/* Favorite button */}
                <button
                  onClick={(e) => handleFavoriteToggle(e, stay)}
                  className="absolute top-4 right-4 bg-white bg-opacity-90 p-2 rounded-full shadow-md"
                >
                  <SafeIcon
                    icon={FiHeart}
                    className={`h-5 w-5 ${isFavorite(stay.id) ? 'text-red-500 fill-current' : 'text-gray-600'}`}
                  />
                </button>
                {/* Zoom to location button */}
                <button
                  onClick={() => zoomToStay(stay)}
                  className="absolute bottom-4 right-4 bg-primary-600 text-white p-2 rounded-full shadow-md hover:bg-primary-700 transition-colors"
                  title="View on map"
                >
                  <SafeIcon icon={FiZoomIn} className="h-5 w-5" />
                </button>
              </motion.div>
            ))}
          </div>
        )}

        {filteredStays.length === 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center py-16 bg-white rounded-2xl shadow-sm"
          >
            <SafeIcon icon={FiFilter} className="h-12 w-12 text-gray-300 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-900 mb-2">No stays found</h3>
            <p className="text-gray-500 text-lg mb-6">
              No stays match your current filters. Try adjusting your search criteria.
            </p>
            <button
              onClick={clearAllFilters}
              className="inline-flex items-center px-6 py-3 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors"
            >
              <SafeIcon icon={FiX} className="h-5 w-5 mr-2" />
              Clear all filters
            </button>
          </motion.div>
        )}
      </div>
    </motion.div>
  );
};

export default DestinationsPage;